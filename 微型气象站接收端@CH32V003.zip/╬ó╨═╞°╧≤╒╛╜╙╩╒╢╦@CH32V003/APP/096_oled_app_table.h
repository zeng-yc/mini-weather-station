#ifndef __096_OLED_APP_ARRAYS_H
#define __096_OLED_APP_ARRAYS_H

#include "oled.h"

extern const uint8_t OLED_ASCII_8x16_Table[];
extern const uint8_t OLED_CHN_16x16_Table[];

void OLED_Char_EN(uint8_t cha, uint8_t px, OLED_PAGE page);
void OLED_String(uint8_t *str, uint8_t px, OLED_PAGE page);
void OLED_Repeat_String(uint8_t* current_str, uint8_t* new_str, uint8_t px, OLED_PAGE page);

#endif  /* __096_OLED_APP_ARRAYS_H */
