#ifndef __096_OLED_RTC_H
#define __096_OLED_RTC_H

#include "096_oled_app_table.h"
#include "rtc.h"

uint8_t OLED_RTC_PartTime(uint8_t *rtc_data, int32_t uts, uint8_t px, OLED_PAGE page);

#endif /**__096_OLED_RTC_H**/
