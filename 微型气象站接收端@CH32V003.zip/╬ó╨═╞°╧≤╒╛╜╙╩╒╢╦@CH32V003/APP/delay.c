#include "delay.h"

/**
  * @brief  微秒级延时函数
  * @note   约20个NOP指令延时约1us(CH32V003 @24MHz测得)
  * @param  None
  * @retval None
  */
void Delay_US(uint32_t count)
{
    do {
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //1
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //2
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //3
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //4
    }while(--count);
}

/**
  * @brief  毫秒级延时函数
  * @note   约20K个NOP指令延时约1ms(CH32V003 @24MHz测得)
  * @param  None
  * @retval None
  */
void Delay_MS(uint32_t count)
{
    count *= 1000;
    do {
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //1
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //2
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //3
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //4
    }while(--count);
}
