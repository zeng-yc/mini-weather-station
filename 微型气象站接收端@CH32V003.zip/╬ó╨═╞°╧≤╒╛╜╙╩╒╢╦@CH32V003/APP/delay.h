#ifndef __DELAY_H
#define __DELAY_H

#include "ch32v00x.h"

void Delay_US(uint32_t count);
void Delay_MS(uint32_t count);

#endif  /* __DELAY_H */
