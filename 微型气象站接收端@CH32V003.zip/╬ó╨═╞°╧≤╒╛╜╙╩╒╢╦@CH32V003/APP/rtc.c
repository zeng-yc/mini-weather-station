#include "rtc.h"

/**
  * @brief   判断年份是否是闰年
  * @note    None
  * @param   year:需要判断的年份
  * @retval  1：是闰年；0：不是闰年
  */
static uint8_t Is_Leap_Year(uint16_t year)
{
    if(((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0))
    {
        return 1;   //能被4整除且不是100的倍数,是普通闰年;能被400整除是世纪闰年(例如1900不是闰年,2000年是世纪闰年)
    }
    else
    {
        return 0;
    }
}

/**
  * @brief   初始化RTC工作模式和时间参数
  * @note    初始化RTC时钟源,北京时间换算成UNIX时间戳写入RTC计数寄存器
  * @param   TIME：当前时间结构体变量
  *          utc_count：当前UTC时间戳
  * @retval  None
  */
void RTC_UTC_Time(RTC_TimeTypeDef *TIME, uint32_t count)
{
    uint16_t temp = 1970;  //临时变量
    uint8_t rtc_month_table[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}; //平年每月天数
    
    /*将UTC时间戳换为北京时间(GMT+8)*/
    count += 8 *3600;
    
    /*计算当前年份*/
    while(count >= 31536000)        //当计数值减到小于一个平年的总秒数数时,表示到了当前年份
    {
        count -= 31536000;          //减去一个平年的总秒数
        if(Is_Leap_Year(temp))      //如果是闰年多减一天的秒数
        {
            count -= 86400;     
        }
        temp++;                     //计数年份
    }
    TIME->year = temp;              //跳出循环表示已计算到当前计数值年份
    
    /*判断当前年份是否是闰年*/
    if(Is_Leap_Year(TIME->year))
    {
        rtc_month_table[1] = 29;    //闰年2月29天
    }
    else
    {
        rtc_month_table[1] = 28;    //平年2月28天
    }
    
    /*计算当前年份已过去的天数*/
    temp = count / 86400;
    
    /*计算今天已过去的秒数*/
    count -= temp * 86400;
    
    /*计算目前的时间*/
    TIME->hour = count / 3600;      //小时
    TIME->min = count % 3600 / 60;  //分钟
    TIME->sec = count % 60;         //秒钟
    
    /*计算日期*/
    for(count = 0; count < 12; count++)
    {
        if(temp < rtc_month_table[count])   //当年已过去的天数逐月减去1月开始的天数,如果小于目前月份天数,则处于当前比对的(月份+1)
        {
            TIME->month = count + 1;        //计数自0开始计数,自然月从1开始计数，所以需要+1
            TIME->day = temp + 1;           //剩余的天数为当月已过去的天数，+1即为目前的天数
            break;                          //计算到时机日期即可退出计算
        }
        temp -= rtc_month_table[count];     //总天数逐月减去1月至当前月份之前的天数
    }
    
    /*计算目前星期天数(https://bbs.csdn.net/topics/70277519,将一和二月作为上一年的第13和第14个月参与计算)*/
    /*吉姆拉尔森公式:week=(day+2*month+3*(month+1)/5+year+year/4-y/100+y/400)%7,得到结果0~6,+1即为目前星期天数*/
    if(TIME->month == 1 || TIME->month == 2)
    {
        count = TIME->month + 12;
        temp = TIME->year - 1;
    }
    else
    {
        count = TIME->month;
        temp = TIME->year;
    }
    TIME->week = (TIME->day + 2 * count + 3 * (count + 1) / 5 + temp + temp / 4 - temp / 100 + temp / 400) % 7 + 1;
}

/**
  * @brief  将当前部分时间数据转换为对应ASCII码值
  * @note   时间数据包括：月、日、时、分、星期
  * @param  Time:当前时间数据结构体变量
  *         Temp_str:本次转换的显示数据的地址
  * @retval None
  */
void RTC_HandleRawData_Part(RTC_TimeTypeDef *Time, uint8_t *Temp_str)
{
#if 0
    Temp_str[0] = Time->month / 10 + 0x30;      //月份十位转为ASCII码
    Temp_str[1] = Time->month % 10 + 0x30;      //月份个位转为ASCII码
    Temp_str[2] = '/';                          //分隔符‘/’
    Temp_str[3] = Time->day / 10 + 0x30;        //日十位转为ASCII码
    Temp_str[4] = Time->day % 10 + 0x30;        //日个位转为ASCII码
    Temp_str[5] = ' ';                          //分隔符‘ ’
    Temp_str[6] = Time->hour / 10 + 0x30;       //小时位转为ASCII码
    Temp_str[7] = Time->hour % 10 + 0x30;       //小数个位转为ASCII码
    Temp_str[8] = ':';                          //分隔符‘:’
    Temp_str[9] = Time->min / 10 + 0x30;        //分钟十位转为ASCII码
    Temp_str[10] = Time->min % 10 + 0x30;       //分钟个位转为ASCII码
    Temp_str[11] = ' ';                         //分隔符‘ ’

    /*根据星期天数转换对应的字符*/
    switch(Time->week) {
        case 1: Temp_str[12] = 'M'; Temp_str[13] = 'o'; Temp_str[14] = 'n'; break;
        case 2: Temp_str[12] = 'T'; Temp_str[13] = 'u'; Temp_str[14] = 'e'; break;
        case 3: Temp_str[12] = 'W'; Temp_str[13] = 'e'; Temp_str[14] = 'd'; break;
        case 4: Temp_str[12] = 'T'; Temp_str[13] = 'h'; Temp_str[14] = 'u'; break;
        case 5: Temp_str[12] = 'F'; Temp_str[13] = 'r'; Temp_str[14] = 'i'; break;
        case 6: Temp_str[12] = 'S'; Temp_str[13] = 'a'; Temp_str[14] = 't'; break;
        case 7: Temp_str[12] = 'S'; Temp_str[13] = 'u'; Temp_str[14] = 'n'; break;
        default: Temp_str[12] = 'E'; Temp_str[13] = 'R'; Temp_str[14] = 'R'; break;
    }
    Temp_str[15] = '\0';                         //最后一个元素以'\0'标定,LCD显示函数结束标定字符
#else
    Temp_str[0] = Time->month / 10 + 0x30;      //月份十位转为ASCII码
    Temp_str[1] = Time->month % 10 + 0x30;      //月份个位转为ASCII码
    Temp_str[2] = '/';                          //分隔符‘/’
    Temp_str[3] = Time->day / 10 + 0x30;        //日十位转为ASCII码
    Temp_str[4] = Time->day % 10 + 0x30;        //日个位转为ASCII码
    Temp_str[5] = '|';                          //分隔符‘ ’
    Temp_str[6] = Time->hour / 10 + 0x30;       //小时位转为ASCII码
    Temp_str[7] = Time->hour % 10 + 0x30;       //小数个位转为ASCII码
    Temp_str[8] = ':';                          //分隔符‘:’
    Temp_str[9] = Time->min / 10 + 0x30;        //分钟十位转为ASCII码
    Temp_str[10] = Time->min % 10 + 0x30;       //分钟个位转为ASCII码
    Temp_str[11] = ':';                         //分隔符‘:’
    Temp_str[12] = Time->sec / 10 + 0x30;       //秒钟十位转为ASCII码
    Temp_str[13] = Time->sec % 10 + 0x30;       //秒钟个位转为ASCII码
    Temp_str[14] = '|';                         //分隔符‘ ’
    /*根据星期天数转换对应的字符*/
    switch(Time->week) {
        case 1: Temp_str[15] = '1'; break;
        case 2: Temp_str[15] = '2'; break;
        case 3: Temp_str[15] = '3'; break;
        case 4: Temp_str[15] = '4'; break;
        case 5: Temp_str[15] = '5'; break;
        case 6: Temp_str[15] = '6'; break;
        case 7: Temp_str[15] = '7'; break;
        default: Temp_str[15] = 'E';break;
    }
    Temp_str[16] = '\0';                         //最后一个元素以'\0'标定,LCD显示函数结束标定字符
#endif
}
