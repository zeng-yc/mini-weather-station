#include "i2c.h"

/**
  * @brief   初始化I2C1的SCL和SDA引脚
  * @note    PC2复用输出为I2C1的SCL(串行时钟线),PC1复用输出为I2C1的SDA(串行数据线)
  * @param   None
  * @retval  None
  */
static void I2C1_GPIO_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;                       //定义IIC1的GPIO初始化结构体变量
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);   //使能GPIO RCC时钟
    
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_OD;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2;
    GPIO_Init(GPIOC, &GPIO_InitStruct);                     //PC1,PC2配置为复用开漏输出
}

/**
  * @brief   配置I2C1的工作模式
  * @note    SCL时钟频率100KHz,IIC模式运行,时钟线高低电平占空比为2:1,主机地址0xA6,使能主机应答,主机7位寻址
  * @param   None
  * @retval  None
  */
static void I2C1_Mode_Config(void)
{
    I2C_InitTypeDef I2C_InitStruct;                     //定义IIC1初始化结构体变量
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1,ENABLE); //使能I2C1的RCC时钟

    I2C_InitStruct.I2C_Mode = I2C_Mode_I2C;             //I2C模式运行
    I2C_InitStruct.I2C_ClockSpeed = 100000;             //SCL时钟100KHz
    I2C_InitStruct.I2C_OwnAddress1 = 0xA6;              //主机地址0xA6
    I2C_InitStruct.I2C_Ack = I2C_Ack_Enable;            //使能主机应答
    I2C_InitStruct.I2C_DutyCycle = I2C_DutyCycle_16_9;  //时钟线高低电平占空比为9:16
    I2C_InitStruct.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;  //主机7位寻址
    I2C_Init(I2C1, &I2C_InitStruct);                    //初始化I2C1的工作模式
}

/**
  * @brief   初始化I2C1
  * @note    None
  * @param   None
  * @retval  None
  */
void I2C1_Init(void)
{
    I2C1_GPIO_Config();     //初始化I2C1的外设引脚
    I2C1_Mode_Config();     //配置I2C1的工作参数
    I2C_Cmd(I2C1, ENABLE);  //使能I2C1
}
