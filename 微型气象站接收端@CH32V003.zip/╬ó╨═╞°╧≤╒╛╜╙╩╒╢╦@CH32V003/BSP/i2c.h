#ifndef __I2C_H
#define __I2C_H

#include "ch32v00x.h"

void I2C1_Init(void);

#endif  /* __I2C_H */
