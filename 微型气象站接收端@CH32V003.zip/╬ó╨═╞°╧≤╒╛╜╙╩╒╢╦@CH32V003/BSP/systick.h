#ifndef __SYSTICK_H
#define __SYSTICK_H

#include "ch32v00x.h"

/**SysTick�жϷ�����Ӳ��ѹջ����**/
void SysTick_Handler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

void SysTick_Config(uint32_t count);

#endif /* __SYSTICK_H */
