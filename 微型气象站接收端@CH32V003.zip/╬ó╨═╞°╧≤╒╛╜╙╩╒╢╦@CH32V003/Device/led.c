#include "led.h"

/**
  * @brief   板载LED接口初始化
  * @note    None
  * @param   None
  * @retval  None
  */
void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    RCC_APB2PeriphClockCmd(LED1_CLK, ENABLE);   //使能RCC时钟
    
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Pin = LED1_Pin;
    GPIO_Init(LED1_Port, &GPIO_InitStruct);     //推挽输出
    
    LED1_Port->BSHR |= LED1_Pin;                //输出高电平
}
