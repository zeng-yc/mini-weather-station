#include "oled.h"

/**
  * @brief  检查OLED屏幕所在IIC总线的通讯状态
  * @note   None
  * @param  I2C_EVENT：I2C总线事件
  * @retval SUCCESS(获取事件状态成功)；ERROR(获取事件状态失败)
  */
static ErrorStatus OLED_CheckEvent(uint32_t I2C_EVENT)
{
    uint16_t timeout = 5000;        //检查事件次数
    uint32_t flag1 = 0, flag2 = 0;

    do {
    /* 读取I2C状态寄存器的值 */
    flag1 = OLED_I2C->STAR1;
    flag2 = OLED_I2C->STAR2;
    flag2 = flag2 << 16;

    /* 合并两个寄存器的值 */
    flag2 = (flag1 | flag2) & (uint32_t)0x00FFFFFF;
    } while(((flag2 & I2C_EVENT) != I2C_EVENT) && --timeout);

    /* 如非超时(timeout = 0)退出，则返回获取事件成功；否则返回获取事件失败 */
    if (timeout) {
        return SET;
    }
    else {
        OLED_I2C->CTLR1 |= (uint16_t)0x0200;    //置位bit9:STOP位(在传输完当前数据后生停止位)
        return RESET;
    }
}

/**
  * @brief  将一字节数据或指令写入IIC数据寄存器，并等待数据移至移位寄存器（EV8,TxE=1）
  * @note   None
  * @param  data:待发送的数据或指令
  * @retval None
  */
static void OLED_Send_Byte(uint8_t data)
{
    OLED_I2C->DATAR = data;
    OLED_CheckEvent(I2C_EVENT_MASTER_BYTE_TRANSMITTING);
}

/**
  * @brief  向OLED屏幕主控SSD1306连续发送多个字节的指令
  * @note   None
  * @param  *pbuf：发送的命令或者数据
  *         cnt：发送的数据或指令个数
  * @retval 1：发送数据成功；非1：IIC通讯过程出错
  */
static uint8_t OLED_Send_Command(uint8_t *pbuf, uint8_t cnt)
{
    /* 1.置位bit8:START位,发送起始信号,等待起始信号发出(EV5事件) */
    OLED_I2C->CTLR1 |= (uint16_t)0x0100;    //I2C_GenerateSTART(I2Cx, ENABLE);
    if(OLED_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT) == RESET)
    {
        return 3;
    }

    /* 2.向总线发送从机地址,等待从机ACK(ADDR位置位),读取状态寄存器SR1和SR2将ADDR位清零(EV6事件) */
    OLED_I2C->DATAR = OLED_ADDR;            //I2C_Send7bitAddress(OLED_I2C, OLED_ADDR, I2C_Direction_Transmitter);
    if(OLED_CheckEvent(I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED) == RESET)
    {
        return 2;
    }

    /* 3.连续发送指令 */
    OLED_Send_Byte(OLED_CMD);
    while(cnt) {
        OLED_Send_Byte(*pbuf); pbuf++; cnt--;
    }

    /* 4.置位bit9:STOP位(在传输完当前数据后生停止位) */
    OLED_I2C->CTLR1 |= (uint16_t)0x0200;
    return 1;
}

/**
  * @brief  初始化0.96吋OLED屏幕的工作模式
  * @note   None
  * @param  None
  * @retval None
  */
void OLED_Init(void)
{
    uint8_t PowerOff[3] = {
            0x8D,0x10,  //关闭电荷泵
            0xAE        //关闭显示
    };
    uint8_t Init_Command[25] = {
            0xAE,       //关闭显示
            0xD5,0x80,  //设置显示时钟分频倍率和振荡器频率
            0xA8,0x3F,  //设置扫描多路行系数
            0xD3,0x00,  //设置不偏移
            0X40,       //起始行40~70F
            0x8D,0x14,  //开启电荷泵
            0x20,0x02,  //内存地址模式设置为页地址模式
            0xA1,       //列扫描顺序：从左到右A1,左右翻转A0
            0XC8,       //行扫描顺序：从上到下C8,上下颠倒C0
            0xDA,0x12,  //行扫描配置
            0x81,0xC8,  //设置屏幕亮度
            0xD9,0xF1,  //设置充放电周期
            0xDB,0x20,  //设置反向截止电压,0.77 x VCC(RESET)
            0xA4,       //A4正常显示（RESET值），A5点亮全部像素点
            0xA6,       //A6正常显示（RESET值），A7反白显示
            0xAF        //开启显示
    };
    OLED_Send_Command(PowerOff, 3);         //关闭屏幕显示
    OLED_Display_Clear();                   //清除屏幕显示
    OLED_Send_Command(Init_Command, 25);    //初始化屏幕工作参数
}

/**
  * @brief  清除0.96吋OLED的全部显示内容
  * @note   None
  * @param  None
  * @retval None
  */
void OLED_Display_Clear(void)
{
    OLED_PAGE page;
    uint8_t i, pixel[128] = {0}, buf[3] = {PAGE0, 0x00, 0x10};

    /* 向一个PAGE(8行点阵)所有点阵填充0 */
    for(i = 0; i < 128; i++) {
        pixel[i] = 0x00;
    }

    /* 逐PAGE清除显示内容 */
    for(page = PAGE0; page <= PAGE7; page++)
    {
        OLED_Send_Font_Stream(buf, pixel, 128);
        buf[0] = page + 1;
    }
}

/**
  * @brief  清除0.96吋OLED的连续2 PAGE的显示内容
  * @note   None
  * @param  page:起始PAGE
  * @retval None
  */
void OLED_Clear_Part(OLED_PAGE page)
{
    uint8_t i, pixel[128] = {0}, buf[3] = {page, 0x00, 0x10};

    /* 向一个PAGE(8行点阵)所有点阵填充0 */
    for(i = 0; i < 128; i++)
    {
        pixel[i] = 0x00;
    }

    /* 清除一行点阵显示内容 */
    OLED_Send_Font_Stream(buf, pixel, 128);
    buf[0] += 1;
    if(buf[0] <= PAGE7)
    {
        OLED_Send_Font_Stream(buf, pixel, 128);
    }
}

/**
  * @brief  向0.96吋OLED主控SSD1306发送字模数据起始行和列地址和字模数据
  * @note   None
  * @param  g_buf:起始行列地址
  *         f_buf:字模数据地址
  *         f_cnt:字模数据个数
  * @retval 发送状态：1：发送成功；非1：IIC通讯过程出错
  */
uint8_t OLED_Send_Font_Stream(uint8_t *g_buf, uint8_t *f_buf, uint8_t f_cnt)
{
    uint8_t cmd_cnt = 3;    //向OLED发送字模显示区域起始地址指令数量为3字节

    /* 1.置位bit8:START位,发送起始信号,等待起始信号发出(EV5事件) */
    OLED_I2C->CTLR1 |= (uint16_t)0x0100;    //I2C_GenerateSTART(I2Cx, ENABLE);
    if(OLED_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT) == RESET)
    {
        return 5;
    }

    /* 2.向总线发送从机地址，等待从机ACK(ADDR位置位)，读取状态寄存器SR1和SR2将ADDR位清零(EV6事件) */
    OLED_I2C->DATAR = OLED_ADDR;            //I2C_Send7bitAddress(OLED_I2C, OLED_ADDR, I2C_Direction_Transmitter);
    if(OLED_CheckEvent(I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED) == RESET)
    {
        return 4;
    }

    /* 3.发送字模数据显示区域起始地址 */
    OLED_Send_Byte(OLED_CMD);
    while(cmd_cnt) {
        OLED_Send_Byte(*g_buf); g_buf++; cmd_cnt--;
    }

    /* 4.置位bit8:START位,重新发送起始信号,等待起始信号发出(EV5事件) */
    OLED_I2C->CTLR1 |= (uint16_t)0x0100;    //I2C_GenerateSTART(I2Cx, ENABLE);
    if(OLED_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT) == RESET)
    {
        return 3;
    }

    /* 5.向总线发送从机地址，等待从机ACK(ADDR位置位)，读取状态寄存器SR1和SR2将ADDR位清零(EV6事件) */
    OLED_I2C->DATAR = OLED_ADDR;            //I2C_Send7bitAddress(OLED_I2C, OLED_ADDR, I2C_Direction_Transmitter);
    if(OLED_CheckEvent(I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED) == RESET)
    {
        return 2;
    }

    /* 6.连续发送字模数据 */
    OLED_Send_Byte(OLED_DATA);
    while(f_cnt) {
        OLED_Send_Byte(*f_buf); f_buf++; f_cnt--;
    }

    /* 7.置位bit9:STOP位(在传输完当前数据后生停止位) */
    OLED_I2C->CTLR1 |= (uint16_t)0x0200;    //I2C_GenerateSTOP(OLED_I2C, ENABLE);
    return 1;
}
