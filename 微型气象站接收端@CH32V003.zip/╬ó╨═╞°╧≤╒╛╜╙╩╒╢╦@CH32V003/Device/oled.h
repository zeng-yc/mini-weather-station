#ifndef __OLED_H
#define __OLED_H

#include "ch32v00x.h"

#define OLED_I2C    I2C1    //OLED挂载的IIC总线
#define OLED_ADDR   0x78    //OLED IIC地址
#define OLED_CMD    0x00    //写指令命令
#define OLED_DATA   0x40    //写数据命令

/* 0.96吋OLED屏幕显示范围 */
#define OLED_PIXEL_X    128
#define OLED_PIXEL_Y    64

/* OLED行显示范围枚举类型 */
typedef enum {
  PAGE0 = (uint8_t)0xB0,
  PAGE1,
  PAGE2,
  PAGE3,
  PAGE4,
  PAGE5,
  PAGE6,
  PAGE7
} OLED_PAGE;

/*******************************************函数声明*******************************************/
void OLED_Init(void);
void OLED_Display_Clear(void);
void OLED_Clear_Part(OLED_PAGE page);
uint8_t OLED_Send_Font_Stream(uint8_t *g_buf, uint8_t *f_buf, uint8_t f_cnt);

#endif /* __OLED_H */
