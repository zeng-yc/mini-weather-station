#ifndef __130_LCD_ADC_H
#define __130_LCD_ADC_H

#include "adc_app.h"
#include "144_lcd_app.h"

void LCD_130_Lighting_Status(uint16_t adc_raw_value, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);
void LCD_144_Lighting_Status_Re(uint16_t adc_raw_value, LIGHTING_STATUS *last_sta, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);
void LCD_144_CH32_Temp(uint16_t ch_raw1_data, uint16_t ch_raw2_data, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);
void LCD_144_CH32_Temp_Re(uint16_t ch_raw1_data, uint16_t ch_raw2_data, uint8_t *ch_data, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);

#endif  /* __130_LCD_ADC_H */
