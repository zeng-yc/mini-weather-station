#ifndef __130_LCD_AHT21B_H
#define __130_LCD_AHT21B_H

#include "aht21b.h"
#include "144_lcd_app.h"

void LCD_144_AHT21B_T(uint32_t aht_t_raw_data, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);
void LCD_144_AHT21B_H(uint32_t aht_h_raw_data, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);
void LCD_144_AHT21B_T_Re(uint32_t aht_t_raw_data, uint8_t *aht_t_data, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);
void LCD_144_AHT21B_H_Re(uint32_t aht_h_raw_data, uint8_t *aht_h_data, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);
void LCD_144_AHT21B_T_Cnt_Re(uint32_t aht_t_raw_data, uint8_t *aht_t_data, uint8_t *cnt, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);
void LCD_144_AHT21B_H_Cnt_Re(uint32_t aht_h_raw_data, uint8_t *aht_h_data, uint8_t *cnt, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);

#endif  /* __130_LCD_AHT21B_H */
