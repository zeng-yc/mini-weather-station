#ifndef __130_LCD_BMP280_H
#define __130_LCD_BMP280_H

#include "bmp280.h"
#include "144_lcd_app.h"

void LCD_144_BMP280_T(int32_t bmp_t_raw_data, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);
void LCD_144_BMP280_P(int32_t bmp_p_raw_data, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);
void LCD_144_BMP280_T_Re(int32_t bmp_t_raw_data, uint8_t *bmp_t_data, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);
void LCD_144_BMP280_P_Re(int32_t bmp_p_raw_data, uint8_t *bmp_p_data, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);
void LCD_144_BMP280_T_Cnt_Re(int32_t bmp_t_raw_data, uint8_t *bmp_t_data, uint8_t *cnt, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);
void LCD_144_BMP280_P_Cnt_Re(int32_t bmp_p_raw_data, uint8_t *bmp_p_data, uint8_t *cnt, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);


#endif  /* __130_LCD_BMP280_H */
