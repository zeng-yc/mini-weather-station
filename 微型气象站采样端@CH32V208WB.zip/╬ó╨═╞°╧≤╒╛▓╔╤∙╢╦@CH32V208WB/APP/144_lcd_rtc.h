#ifndef __130_LCD_RTC_H
#define __130_LCD_RTC_H

#include "rtc.h"
#include "144_lcd_app.h"

void LCD_RTC_TotalTime(uint8_t *rtc_data, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);
uint8_t LCD_RTC_PartTime(uint8_t *rtc_data, LCD_144_Mix_FONT fonts, LCD_144_COLOR front_color, LCD_144_COLOR back_color, uint8_t px, uint8_t py);

#endif  /* __130_LCD_RTC_H */
