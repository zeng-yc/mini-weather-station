#include "adc.h"

uint16_t ADC_ConvertedValue[ADC_CHANNEL_NUM] = {0}; //6个ADC通道采样数据缓冲数组

#if 0
/*****************************************************
 * @brief   初始化ADC DMA传输完成中断
 * @note    无
 * @param   无
 * @retval  无
*****************************************************/
static void ADC1_DMA_NVIC_Config(void)
{
    NVIC_InitTypeDef NVIC_InitStuct;                        //定义中断控制器初始化结构体变量
    NVIC_InitStuct.NVIC_IRQChannel = DMA1_Channel1_IRQn;    //中断源DMA1_Channel1
    NVIC_InitStuct.NVIC_IRQChannelPreemptionPriority = 4;   //抢占优先级4(0~7)
    NVIC_InitStuct.NVIC_IRQChannelSubPriority = 1;          //响应优先级1(0~1)
    NVIC_InitStuct.NVIC_IRQChannelCmd = ENABLE;             //使能中断
    NVIC_Init(&NVIC_InitStuct);                             //初始化ADC DMA传输完成中断
}

#endif

/*****************************************************
 * @brief   初始化串ADC通道0~3(PA0~PA3)的引脚
 * @note    配置PA0~PA3为模拟输入
 * @param   无
 * @retval  无
*****************************************************/
static void ADC1_GPIO_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStruce;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    
    GPIO_InitStruce.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_InitStruce.GPIO_Pin = GPIO_Pin_0;
    GPIO_Init(GPIOA, &GPIO_InitStruce);
}

/*****************************************************
 * @brief   配置ADC1 DMA工作模式
 * @note    无
 * @param   无
 * @retval  无
*****************************************************/
static void ADC1_DMA_Config(void)
{
    DMA_InitTypeDef DMA_InitStruce;                                     //定义DMA初始化结构体变量
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);                  //开启DMA1的RCC时钟

    DMA_DeInit(DMA1_Channel1);                                          //复位DAM1通道1
    DMA_InitStruce.DMA_PeripheralBaseAddr = (uint32_t)&ADC1->RDATAR;    //外设地址,ADC_RDATAR(ADC规则通道数据寄存器)
    DMA_InitStruce.DMA_MemoryBaseAddr = (uint32_t)ADC_ConvertedValue;   //存储器地址
    DMA_InitStruce.DMA_DIR = DMA_DIR_PeripheralSRC;                     //传输方向(P->M)
    DMA_InitStruce.DMA_BufferSize = ADC_CHANNEL_NUM;                    //设置数据传输数量
    DMA_InitStruce.DMA_PeripheralInc = DMA_PeripheralInc_Disable;       //外设地址不自增(ADC规则通道数据寄存器(ADC_RDATAR)是固定地址)
    DMA_InitStruce.DMA_MemoryInc = DMA_MemoryInc_Enable;                //存储器地址需要自增(ADC采集转换数据要按序缓存至数组，地址需要自增)
    DMA_InitStruce.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;    //外设和存储器的数据宽度都设置成16位(ADC采集的数据是12位)
    DMA_InitStruce.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;    
    DMA_InitStruce.DMA_Mode = DMA_Mode_Circular;                        //传输模式:循环模式
    DMA_InitStruce.DMA_Priority = DMA_Priority_Medium;                  //DMA优先级:中
    DMA_InitStruce.DMA_M2M = DMA_M2M_Disable;                           //不使用M->M
    DMA_Init(DMA1_Channel1, &DMA_InitStruce);                           //初始化DMA1的通道1(ADC1 DMA通道位于DMA1的通道1)
}

/*****************************************************
 * @brief   配置ADC1工作模式
 * @note    无
 * @param   无
 * @retval  无
*****************************************************/
static void ADC1_Mode_Config(void)
{
    ADC_InitTypeDef ADC_InitStruct;                         //定义ADC1初始化结构体变量
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);    //开启ADC1 RCC时钟
    ADC_InitStruct.ADC_Mode = ADC_Mode_Independent;         //独立模式
    ADC_InitStruct.ADC_ScanConvMode = ENABLE;               //使能多通道扫描
    ADC_InitStruct.ADC_ContinuousConvMode = DISABLE;        //不使用连续转换
    ADC_InitStruct.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;    //软件触发采样
    ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;     //采集数据右对齐
    ADC_InitStruct.ADC_NbrOfChannel = ADC_CHANNEL_NUM;      //采集通道数
    ADC_Init(ADC1, &ADC_InitStruct);                        //初始化ADC1
}

/*****************************************************
 * @brief   初始化ADC1
 * @note    无
 * @param   无
 * @retval  无
*****************************************************/
void ADC1_Init(void)
{
    ADC1_GPIO_Config();     //初始化ADC外设引脚
    ADC1_Mode_Config();     //初始化ADC1工作模式
//    ADC1_DMA_NVIC_Config(); //配置ADC1的DMA中断模式
    ADC1_DMA_Config();      //配置ADC1的DMA通道工作模式
    
    ADC_TempSensorVrefintCmd(ENABLE);   //使能内部温度传感器、内部基准电压采样
    RCC_ADCCLKConfig(RCC_PCLK2_Div8);   //配置ADC的时钟为PCLK2的8分频：120MHz/8 = 15MHz

    //配置ADC转换通道为0~3(PA0~PA3)、16(内置温度传感器)、17(内部参考基准电压)，设置转换顺序，采样周期为N个周期+固定12.5转换周期
    ADC_RegularChannelConfig(ADC1, ADC_Channel_17, 1, ADC_SampleTime_239Cycles5);   //16.8us
    ADC_RegularChannelConfig(ADC1, ADC_Channel_16, 2, ADC_SampleTime_239Cycles5);   //16.8us
    ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 3, ADC_SampleTime_239Cycles5);    //16.8us
//    ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 4, ADC_SampleTime_239Cycles5);    //16.8us

//    DMA_ClearFlag(DMA1_FLAG_TC1);                       //复位DMA1通道1传输完成中断标志位
//    DMA_ITConfig(DMA1_Channel1, DMA_IT_TC, ENABLE);     //使能DMA1通道1传输完成中断
    DMA_Cmd(DMA1_Channel1, ENABLE);                     //使能DMA1通道1（ADC）

    ADC_Cmd(ADC1, ENABLE);                              //使能ADC1
    ADC_DMACmd(ADC1, ENABLE);                           //使能ADC1的DMA请求
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);             //软件触发ADC1采样
//    ADC_ExternalTrigConvCmd(ADC1, ENABLE);              //使能ADC1外部触发(TIM3计数器值更新)
    
    /**启动校准前，必须保证ADC模块处于上电状态(ADON=1)超过至少两个ADC时钟周期**/
    ADC_ResetCalibration(ADC1);                         //初始化ADC1的校准寄存器
    while(ADC_GetResetCalibrationStatus(ADC1));         //等待校准寄存器初始化完成
    ADC_StartCalibration(ADC1);                         //开启ADC1校准
    while(ADC_GetCalibrationStatus(ADC1));              //等待ADC校准完成
}
