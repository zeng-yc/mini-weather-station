#ifndef __ADC_H
#define __ADC_H

#include "ch32v20x.h"

#define ADC_CHANNEL_NUM     3   //ADC采样通道数量

extern uint16_t ADC_ConvertedValue[ADC_CHANNEL_NUM];    //ADC通道采样数据缓冲数组

void ADC1_Init(void);

#endif /* __ADC_H */
