#ifndef __RTC_H
#define __RTC_H

#include "ch32v20x.h"

/** 
  * @brief  UTCʱ���תΪ����ʱ��ṹ��  
  */
typedef struct
{
  uint16_t  year;   //���
  uint8_t   month;  //�·�
  uint8_t   day;    //��
  uint8_t   hour;   //Сʱ
  uint8_t   min;    //����
  uint8_t   sec;    //����
  uint8_t   week;   //����
} RTC_TimeTypeDef;

uint8_t RTC_Init(void);
void RTC_Counter_Config(uint32_t CounterValue);
void RTC_UTC_Time(RTC_TimeTypeDef *TIME, uint32_t count);
void RTC_HandleRawData_Total(RTC_TimeTypeDef *Time, uint8_t *Temp_str);
void RTC_HandleRawData_Part(RTC_TimeTypeDef *Time, uint8_t *Temp_str);

#endif /* __RTC_H */
