#include "spi_1.h"

/**
  * @brief  初始化DMA SPI1 Rx通道中断控制器
  * @note   DMA1_CH2(SPI1_RX)
  * @param  None
  * @retval None
  */
static void SPI1_DMA_NVIC_Config(void)
{
    NVIC_InitTypeDef NVIC_InitStruct;                           //定义NVIC初始化结构体变量

    NVIC_InitStruct.NVIC_IRQChannel = DMA1_Channel2_IRQn;       //中断来源(SPI1 Rx)
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;      //抢占优先级(0~7)
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;             //子优先级(0~1)
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;                //使能中断
    NVIC_Init(&NVIC_InitStruct);                                //初始化中断参数
}

/**
  * @brief  初始化SPI1 DMA通道工作模式
  * @note   DMA单次传输模式
  * @param  None
  * @retval None
  */
static void SPI1_DMA_Config(void)
{
    DMA_InitTypeDef DMA_InitStruct;                                     //定义DMA初始化结构体变量
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);                  //开启DMA1的RCC时钟

    DMA_DeInit(DMA1_Channel2);                                          //复位DAM1通道2(SPI1_RX)
    DMA_InitStruct.DMA_PeripheralBaseAddr = SPI1_BASE + 0x0C;           //DMA通道外设地址,SPI1数据寄存器(SPI1_DATAR)
    DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralSRC;                     //传输方向(P->M)
    DMA_InitStruct.DMA_PeripheralInc = DMA_PeripheralInc_Disable;       //外设地址不自增(SPI_DR是固定地址，不需要自增)
    DMA_InitStruct.DMA_MemoryInc = DMA_MemoryInc_Enable;                //存储器地址需要自增
    DMA_InitStruct.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;        //存储器数据宽带设置成8位
    DMA_InitStruct.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;//外设数据宽带设置成8位
    DMA_InitStruct.DMA_Mode = DMA_Mode_Normal;                          //不执行循环操作
    DMA_InitStruct.DMA_Priority = DMA_Priority_VeryHigh;                //设置优先级
    DMA_InitStruct.DMA_M2M = DMA_M2M_Disable;                           //不使用M->M
    DMA_Init(DMA1_Channel2, &DMA_InitStruct);                           //初始化DMA1通道2(SPI1_RX)

    DMA_DeInit(DMA1_Channel3);                                          //复位DAM1通道3(SPI1_TX)
    DMA_InitStruct.DMA_PeripheralBaseAddr = SPI1_BASE + 0x0C;           //DMA通道外设地址,SPI1数据寄存器(SPI1_DATAR)
    DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralDST;                     //传输方向(P->M)
    DMA_Init(DMA1_Channel3, &DMA_InitStruct);                           //初始化DMA1通道3(SPI1_TX)

    DMA_ITConfig(DMA1_Channel2, DMA_IT_TC, ENABLE);                     //使能DMA1_Channel2传输完成中断

    DMA_Cmd(DMA1_Channel2, DISABLE);        //关闭DMA1通道2(SPI1_RX),执行单次DMA传输,使用时开启
    DMA_Cmd(DMA1_Channel3, DISABLE);        //关闭DMA1通道3(SPI1_TX),执行单次DMA传输,使用时开启
}

/**
  * @brief  初始化SPI1的SCK、MISO、MOSI外设引脚
  * @note   SPI1：SCK/PB3，MISO/PB4，MOSI/PB5
  * @param  None
  * @retval None
  */
static void SPI1_GPIO_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;                       //定义GPIO初始化结构体变量
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);   //使能GPIO RCC时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);    //使能GPIO重映射RCC时钟

    GPIO_PinRemapConfig(GPIO_Remap_SPI1, ENABLE);           //重映射SPI1的引脚(NSS/PA15，SCK/PB3，MISO/PB4，MOSI/PB5)

    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;    
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;   
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_5;
    GPIO_Init(GPIOB, &GPIO_InitStruct);                     //PB3、PB5配置为复用推挽输出

    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_4;
    GPIO_Init(GPIOB, &GPIO_InitStruct);                     //PB4配置为浮空输入
}

/**
  * @brief   初始化SPI1的工作模式
  * @note    注意SCK频率不要超过外设能支持的最大频率
  * @param   无
  * @retval  无
  */
static void SPI1_Mode_Config(void)
{
    SPI_InitTypeDef SPI_InitStruct;                                     //定义初始化结构体变量
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);                //使能SPI2 RCC时钟

    SPI_InitStruct.SPI_Mode = SPI_Mode_Master;                          //主模式
    SPI_InitStruct.SPI_Direction = SPI_Direction_2Lines_FullDuplex;     //全双工模式
    SPI_InitStruct.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_16;    //SCK=120MHz/16=7.5MHz
    SPI_InitStruct.SPI_DataSize = SPI_DataSize_8b;                      //数据帧8位
    SPI_InitStruct.SPI_FirstBit = SPI_FirstBit_MSB;                     //MSB先行
    SPI_InitStruct.SPI_CPOL = SPI_CPOL_High;                            //时钟极性CPOL为高电平
    SPI_InitStruct.SPI_CPHA = SPI_CPHA_2Edge;                           //时钟相位CPHA为偶数边沿
    SPI_InitStruct.SPI_NSS = SPI_NSS_Soft;                              //从设备选择NSS配置成软件模式
    SPI_InitStruct.SPI_CRCPolynomial = 0x0007;                          //不使用 CRC校验，配置成CRC多项式寄存器复位值0x0007
    SPI_Init(SPI1, &SPI_InitStruct);                                    //初始化SPI1工作模式
}

/**
  * @brief   初始化SPI1
  * @note    无
  * @param   无
  * @retval  无
  */
void SPI1_Init(void)
{
    SPI1_DMA_NVIC_Config();  //配置DMA SPI1 TX和RX通道中断控制器
    SPI1_DMA_Config();       //配置DMA SPI1 TX和RX通道工作模式
    SPI1_GPIO_Config();      //初始化SPI1外设GPIO
    SPI1_Mode_Config();      //配置SPI1工作模式
    SPI_I2S_DMACmd(SPI1, SPI_I2S_DMAReq_Rx, ENABLE);    //SPI1 RX使能DMA功能
    SPI_I2S_DMACmd(SPI1, SPI_I2S_DMAReq_Tx, ENABLE);    //SPI1 TX使能DMA功能
    SPI_Cmd(SPI1, ENABLE);  //使能SPI1
}
