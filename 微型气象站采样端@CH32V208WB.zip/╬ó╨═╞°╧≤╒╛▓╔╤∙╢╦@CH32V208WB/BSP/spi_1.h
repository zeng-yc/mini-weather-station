#ifndef __SPI_1_H
#define __SPI_1_H

#include "ch32v20x.h"

void SPI1_Init(void);

#endif /* __SPI_1_H */
