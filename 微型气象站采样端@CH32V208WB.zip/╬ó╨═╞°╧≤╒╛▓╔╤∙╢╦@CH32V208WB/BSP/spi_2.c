#include "spi_2.h"

/**
  * @brief  初始化DMA SPI2 Rx通道中断控制器
  * @note   DMA1_CH4(SPI2_RX)
  * @param  None
  * @retval None
  */
static void SPI2_DMA_NVIC_Config(void)
{
    NVIC_InitTypeDef NVIC_InitStruct;                           //定义NVIC初始化结构体变量

    NVIC_InitStruct.NVIC_IRQChannel = DMA1_Channel4_IRQn;       //中断来源(SPI2 Rx)
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 3;      //抢占优先级(0~7)
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;             //子优先级(0~1)
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;                //使能中断
    NVIC_Init(&NVIC_InitStruct);                                //初始化中断参数
}

/**
  * @brief  初始化SPI2 DMA通道工作模式
  * @note   DMA单次传输模式
  * @param  None
  * @retval None
  */
static void SPI2_DMA_Config(void)
{
    DMA_InitTypeDef DMA_InitStruct;                                     //定义DMA初始化结构体变量
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);                  //开启DMA1的RCC时钟

    DMA_DeInit(DMA1_Channel4);                                          //复位DAM1通道4(SPI2_RX)
    DMA_InitStruct.DMA_PeripheralBaseAddr = SPI2_BASE + 0x0C;           //DMA通道外设地址,SPI2数据寄存器(SPI2_DATAR)
    DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralSRC;                     //传输方向(P->M)
    DMA_InitStruct.DMA_PeripheralInc = DMA_PeripheralInc_Disable;       //外设地址不自增(SPI_DR是固定地址，不需要自增)
    DMA_InitStruct.DMA_MemoryInc = DMA_MemoryInc_Enable;                //存储器地址需要自增
    DMA_InitStruct.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;        //存储器数据宽带设置成8位
    DMA_InitStruct.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;//外设数据宽带设置成8位
    DMA_InitStruct.DMA_Mode = DMA_Mode_Normal;                          //不执行循环操作
    DMA_InitStruct.DMA_Priority = DMA_Priority_VeryHigh;                //设置优先级
    DMA_InitStruct.DMA_M2M = DMA_M2M_Disable;                           //不使用M->M
    DMA_Init(DMA1_Channel4, &DMA_InitStruct);                           //初始化DMA1通道4(SPI2_RX)

    DMA_DeInit(DMA1_Channel5);                                          //复位DAM1通道5(SPI2_TX)
    DMA_InitStruct.DMA_PeripheralBaseAddr = SPI2_BASE + 0x0C;           //DMA通道外设地址,SPI2数据寄存器(SPI2_DATAR)
    DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralDST;                     //传输方向(P->M)
    DMA_Init(DMA1_Channel5, &DMA_InitStruct);                           //初始化DMA1通道5(SPI2_TX)

    DMA_ITConfig(DMA1_Channel4, DMA_IT_TC, ENABLE);                     //使能DMA1_Channel4传输完成中断

    DMA_Cmd(DMA1_Channel4, DISABLE);        //关闭DMA1通道4(SPI2_RX),执行单次DMA传输,使用时开启
    DMA_Cmd(DMA1_Channel5, DISABLE);        //关闭DMA1通道5(SPI2_TX),执行单次DMA传输,使用时开启
}

/**
  * @brief  初始化SPI2的SCK、MISO、MOSI的外设引脚
  * @note   SPI2：SCK（PB13）、MISO（PB14）、MOSI（PB15）
  * @param  None
  * @retval None
  */
static void SPI2_GPIO_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;                       //定义GPIO初始化结构体变量
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);   //开启GPIO RCC时钟

    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;    
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;   
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_15;
    GPIO_Init(GPIOB, &GPIO_InitStruct);                     //PB13、PB15配置为复用推挽输出

    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_14;
    GPIO_Init(GPIOB, &GPIO_InitStruct);                     //PB14配置为浮空输入
}

/**
  * @brief   初始化SPI2的工作模式
  * @note    注意SCK频率不要超过外设能支持的最大频率
  * @param   无
  * @retval  无
  */
static void SPI2_Mode_Config(void)
{
    SPI_InitTypeDef SPI_InitStruct;                                     //定义初始化结构体变量
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);                //使能SPI2 RCC时钟

    SPI_InitStruct.SPI_Mode = SPI_Mode_Master;                          //主模式
    SPI_InitStruct.SPI_Direction = SPI_Direction_2Lines_FullDuplex;     //全双工模式
    SPI_InitStruct.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_4;     //SCK=60MHz/4=15MHz
    SPI_InitStruct.SPI_DataSize = SPI_DataSize_8b;                      //数据帧8位
    SPI_InitStruct.SPI_FirstBit = SPI_FirstBit_MSB;                     //MSB先行
    SPI_InitStruct.SPI_CPOL = SPI_CPOL_Low;                             //时钟极性CPOL为低电平
    SPI_InitStruct.SPI_CPHA = SPI_CPHA_1Edge;                           //时钟相位CPHA为奇数边沿
    SPI_InitStruct.SPI_NSS = SPI_NSS_Soft;                              //从设备选择NSS配置成软件模式
    SPI_InitStruct.SPI_CRCPolynomial = 0x0007;                          //不使用 CRC校验，配置成CRC多项式寄存器复位值0x0007
    SPI_Init(SPI2, &SPI_InitStruct);                                    //初始化SPI2工作模式
}

/**
  * @brief   初始化SPI2
  * @note    无
  * @param   无
  * @retval  无
  */
void SPI2_Init(void)
{
    SPI2_DMA_NVIC_Config();  //配置DMA SPI2 TX和RX通道中断控制器
    SPI2_DMA_Config();       //配置DMA SPI2 TX和RX通道工作模式
    SPI2_GPIO_Config();      //初始化SPI2外设GPIO
    SPI2_Mode_Config();      //配置SPI2工作模式
    SPI_I2S_DMACmd(SPI2, SPI_I2S_DMAReq_Rx, ENABLE);    //SPI2 RX使能DMA功能
    SPI_I2S_DMACmd(SPI2, SPI_I2S_DMAReq_Tx, ENABLE);    //SPI2 TX使能DMA功能
    SPI_Cmd(SPI2, ENABLE);  //使能SPI2
}
