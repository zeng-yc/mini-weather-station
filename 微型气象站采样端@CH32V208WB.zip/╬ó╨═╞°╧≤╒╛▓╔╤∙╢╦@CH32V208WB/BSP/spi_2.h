#ifndef __SPI_2_H
#define __SPI_2_H

#include "ch32v20x.h"

void SPI2_Init(void);

#endif /* __SPI_2_H */
