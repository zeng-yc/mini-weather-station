/********************************** (C) COPYRIGHT  *******************************
 * File Name          : debug.c
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2021/06/06
 * Description        : This file contains all the functions prototypes for UART
 *                      Printf , Delay functions.
 * Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
 * SPDX-License-Identifier: Apache-2.0
 *******************************************************************************/
#include "debug.h"

/*********************************************************************
 * @fn      ����΢�뼶��ʱ,ϵͳʱ��@120MHz(CH32V208WBU6)
 * @brief   Microsecond Delay Time.
 * @param   us - Microsecond number.
 * @return  None
 */
void Delay_Us(uint32_t us)
{
    do {
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //1
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //2
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //3
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //4
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //5
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //6
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //7
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //8
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //9
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //10
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //11
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //12
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //13
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //14
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //15
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //16
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //17
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //18
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //19
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //20
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //21
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //22
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //23
        asm("nop"); asm("nop");                                     //24
    } while(--us);
}

/*********************************************************************
 * @fn      ���ܺ��뼶��ʱ,ϵͳʱ��@120MHz(CH32V208WBU6)
 * @brief   Millisecond Delay Time.
 * @param   ms - Millisecond number.
 * @return  None
 */
void Delay_Ms(uint32_t ms)
{
    ms *= 1000;
    do {
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //1
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //2
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //3
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //4
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //5
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //6
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //7
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //8
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //9
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //10
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //11
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //12
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //13
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //14
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //15
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //16
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //17
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //18
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //19
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //20
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //21
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //22
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //23
        asm("nop"); asm("nop");                                     //24
    } while(--ms);
}

/**
  * @brief  ��ʼ������1��GPIO
  * @note   PA9����Ϊ����1��TX(����)������PA10���ô���1��RX(����)
  * @param  None
  * @retval None
  */
static void USART1_GPIO_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9;
    GPIO_Init(GPIOA, &GPIO_InitStruct);                     //����PA9�����������

    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;
    GPIO_Init(GPIOA, &GPIO_InitStruct);                     //����PA10��������
}

/**
  * @brief  ���ô���1�Ĺ�������
  * @note   8������λ������&����ģʽ����У�飻1λֹͣλ����Ӳ��������
  * @param  baudrate:ͨѶ������
  * @retval None
  */
static void USART1_Mode_Config(uint32_t baudrate)
{
    USART_InitTypeDef USART_InitStructurt;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

    USART_InitStructurt.USART_BaudRate = baudrate;
    USART_InitStructurt.USART_WordLength = USART_WordLength_8b;
    USART_InitStructurt.USART_StopBits = USART_StopBits_1;
    USART_InitStructurt.USART_Parity = USART_Parity_No;
    USART_InitStructurt.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructurt.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART1, &USART_InitStructurt);
}

/**
  * @brief  ��ʼ������1
  * @note   ��
  * @param  None
  * @retval None
  */
void USART1_Init(uint32_t baudrate)
{
    USART1_GPIO_Config();           //��ʼ������1��������
    USART1_Mode_Config(baudrate);   //��ʼ������1����ģʽ
    USART_Cmd(USART1, ENABLE);      //ʹ�ܴ���1
}

/*********************************************************************
 * @fn      _write
 * @brief   Support Printf Function
 * @param   *buf - UART send Data.
 *          size - Data length
 * @return  size: Data length
 */
__attribute__((used))
int _write(int fd, char *buf, int size)
{
    do{
        while(!(USART1->STATR & USART_FLAG_TC));
        USART1->DATAR = (uint16_t)*buf;
        buf++;
    } while(--size);
    return size;
}

/*********************************************************************
 * @fn      _sbrk
 * @brief   Change the spatial position of data segment.
 * @return  size: Data length
 */
void *_sbrk(ptrdiff_t incr)
{
    extern char _end[];
    extern char _heap_end[];
    static char *curbrk = _end;

    if ((curbrk + incr < _end) || (curbrk + incr > _heap_end))
    return NULL - 1;

    curbrk += incr;
    return curbrk - incr;
}
