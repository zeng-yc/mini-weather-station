#include "144_st7735s.h"

/**
  * @brief  配置接入LCD的Reset,D/C(数据/指令流),BL(背光)引脚的工作模式
  * @note   None
  * @param  None
  * @retval None
  */
void LCD_144_Ctrl_Init(void)
{    
    GPIO_InitTypeDef GPIO_InitStruct;               //定义GPIO初始化结构体变量
    
#if LCD_144_RST_PORT
    RCC_APB2PeriphClockCmd(LCD_144_RST_CLK, ENABLE);

    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Pin = LCD_144_RST_Pin;
    GPIO_Init(LCD_144_RST_Port, &GPIO_InitStruct);  //连接RST的引脚为推挽输出模式

    LCD_144_RST_H;                                  //拉高复位引脚
#endif    /** LCD_144_RST_PORT **/

#if LCD_144_DC_PORT
    RCC_APB2PeriphClockCmd(LCD_144_DC_CLK, ENABLE);

    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Pin = LCD_144_DC_Pin;
    GPIO_Init(LCD_144_DC_Port, &GPIO_InitStruct);   //连接D/C的引脚为推挽输出模式
#endif    /** LCD_144_DC_PORT **/

#if LCD_144_CS_PORT
    RCC_APB2PeriphClockCmd(LCD_144_CS_CLK, ENABLE);

    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Pin = LCD_144_CS_Pin;
    GPIO_Init(LCD_144_CS_Port, &GPIO_InitStruct);   //连接CS的引脚为推挽输出模式

    LCD_144_CS_1;                                   //拉高片选引脚
#endif    /** LCD_144_CS_PORT **/

#if LCD_144_BL_PORT
    RCC_APB2PeriphClockCmd(LCD_144_BL_CLK, ENABLE);

    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Pin = LCD_144_BL_Pin;
    GPIO_Init(LCD_144_BL_Port, &GPIO_InitStruct);   //连接BL的引脚为推挽输出模式

    LCD_144_BL_OFF;                                 //关闭LCD背光
#endif    /** LCD_144_BL_PORT **/
}

/**
  * @brief  微秒级空指令延时
  * @note   CH32V208WBU6 @120MHz
  * @param  None
  * @retval None
  */
static void LCD_144_Delay_Us(uint32_t cnt)
{
    do {
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //1
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //2
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //3
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //4
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //5
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //6
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //7
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //8
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //9
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //10
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //11
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //12
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //13
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //14
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //15
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //16
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //17
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //18
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //19
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //20
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //21
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //22
        asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); //23
        asm("nop"); asm("nop");                                     //24
    } while(--cnt);
}

/**
  * @brief  SPI接收发送一字节数据函数
  * @note   None
  * @param  data:从机发送至主机的数据
  * @retval 主机接收到的数据
  */
static uint8_t LCD_144_SPI_TR_Byte(uint8_t data)
{
    uint16_t cnt = 20000;                                       //超时计数变量
    LCD_144_SPI->DATAR = data;                                  //向发送缓冲区写入数据
    while(!(LCD_144_SPI->STATR & SPI_I2S_FLAG_TXE) && --cnt);   //等待TXE发送缓冲区为空
    cnt = 20000;                                                //重置计数变量
    while((LCD_144_SPI->STATR & SPI_I2S_FLAG_BSY) && --cnt);    //等待BSY位复位(本次通信完成)
    return LCD_144_SPI->DATAR;                                  //读取接收到的数据
}

/**
  * @brief  主机发送一字节的指令到LCD主控ST7735S
  * @note   None
  * @param  cmd:发送到ST7735S的指令
  * @retval None
  */
static void LCD_144_Send_CMD(uint8_t cmd)
{
    LCD_144_CS_0;               //片选LCD
    LCD_144_CMD;                //选择发送至指令寄存器
    LCD_144_SPI_TR_Byte(cmd);   //发送指令
    LCD_144_CS_1;               //取消片选LCD
}

/**
  * @brief  软件复位LCD主控ST7735S
  * @note   None
  * @param  None
  * @retval None
  */
static void LCD_144_Reset(void)
{
    LCD_144_RST_H; LCD_144_Delay_Us(5000);
    LCD_144_RST_L; LCD_144_Delay_Us(20000);
    LCD_144_RST_H; LCD_144_Delay_Us(5000);
    LCD_144_Send_CMD(0x11);     //Sleep out
    LCD_144_Delay_Us(100000);
}

/**
  * @brief  配置LCD主控ST7735S工作模式参数
  * @note   None
  * @param  None
  * @retval None
  */
static void LCD_144_Mode_Config(void)
{
    LCD_144_CS_0;               //片选ST7735S
    /*------ST7735S Frame Rate------*/
    LCD_144_CMD;                //写指令
    LCD_144_SPI_TR_Byte(0xB1);  //Frame rate 80Hz Frame rate=333k/((RTNA + 20) x (LINE + FPA + BPA))
    LCD_144_DATA;               //写数据
    LCD_144_SPI_TR_Byte(0x05);
    LCD_144_SPI_TR_Byte(0x3C);
    LCD_144_SPI_TR_Byte(0x3C);

    LCD_144_CMD;                //写指令
    LCD_144_SPI_TR_Byte(0xB2);  //Frame rate 80Hz
    LCD_144_DATA;               //选写数据
    LCD_144_SPI_TR_Byte(0x05);
    LCD_144_SPI_TR_Byte(0x3C);
    LCD_144_SPI_TR_Byte(0x3C);
    
    LCD_144_CMD;                //写指令
    LCD_144_SPI_TR_Byte(0xB3);  //Frame rate 80Hz
    LCD_144_DATA;               //写数据
    LCD_144_SPI_TR_Byte(0x05);
    LCD_144_SPI_TR_Byte(0x3C);
    LCD_144_SPI_TR_Byte(0x3C);
    LCD_144_SPI_TR_Byte(0x05);
    LCD_144_SPI_TR_Byte(0x3C);
    LCD_144_SPI_TR_Byte(0x3C);
    
    /*------Display Inversion Control------*/
    LCD_144_CMD;                //写指令
    LCD_144_SPI_TR_Byte(0xB4);  //Dot inversion
    LCD_144_DATA;               //写数据
    LCD_144_SPI_TR_Byte(0x03);

    /*------ST7735S Power Sequence------*/
    LCD_144_CMD;                //写指令
    LCD_144_SPI_TR_Byte(0xC0);
    LCD_144_DATA;               //写数据
    LCD_144_SPI_TR_Byte(0x28);
    LCD_144_SPI_TR_Byte(0x08);
    LCD_144_SPI_TR_Byte(0x04);
    
    LCD_144_CMD;                //写指令
    LCD_144_SPI_TR_Byte(0xC1);
    LCD_144_DATA;               //写数据
    LCD_144_SPI_TR_Byte(0xC0);

    LCD_144_CMD;                //写指令
    LCD_144_SPI_TR_Byte(0xC2);
    LCD_144_DATA;               //写数据
    LCD_144_SPI_TR_Byte(0x0D);
    LCD_144_SPI_TR_Byte(0x00);
    
    LCD_144_CMD;                //写指令
    LCD_144_SPI_TR_Byte(0xC3);
    LCD_144_DATA;               //写数据
    LCD_144_SPI_TR_Byte(0x8D);
    LCD_144_SPI_TR_Byte(0x2A);
    
    LCD_144_CMD;                //写指令
    LCD_144_SPI_TR_Byte(0xC4);
    LCD_144_DATA;               //写数据
    LCD_144_SPI_TR_Byte(0x8D);
    LCD_144_SPI_TR_Byte(0xEE);
    
    /*------End ST7735S Power Sequence------*/
    LCD_144_CMD;                //写指令
    LCD_144_SPI_TR_Byte(0xC5);  //VCOM
    LCD_144_DATA;               //写数据
    LCD_144_SPI_TR_Byte(0x1A);
    
    LCD_144_CMD;                //写指令
    LCD_144_SPI_TR_Byte(0x36);  //MX, MY, RGB mode
    LCD_144_DATA;               //写数据

    /* 配置LCD显示起始方向 */
#if LCD_144_DISPLAY_DIRECTION == LCD_144_DISPLAY_TOP
    LCD_144_SPI_TR_Byte(0xC8);  //排针朝上
#elif LCD_144_DISPLAY_DIRECTION == LCD_144_DISPLAY_DOWN
    LCD_144_SPI_TR_Byte(0x08);  //排针朝下
#elif LCD_144_DISPLAY_DIRECTION == LCD_144_DISPLAY_LEFT
    LCD_144_SPI_TR_Byte(0xA8);  //排针朝左
#elif LCD_144_DISPLAY_DIRECTION == LCD_144_DISPLAY_RIGHT
    LCD_144_SPI_TR_Byte(0x68);  //排针朝右
#endif

    /*------ST7735S Gamma Sequence------*/
    LCD_144_CMD;                //写指令
    LCD_144_SPI_TR_Byte(0xE0);
    LCD_144_DATA;               //写数据
    LCD_144_SPI_TR_Byte(0x04);
    LCD_144_SPI_TR_Byte(0x22);
    LCD_144_SPI_TR_Byte(0x07);
    LCD_144_SPI_TR_Byte(0x0A);
    LCD_144_SPI_TR_Byte(0x2E);
    LCD_144_SPI_TR_Byte(0x30);
    LCD_144_SPI_TR_Byte(0x25);
    LCD_144_SPI_TR_Byte(0x2A);
    LCD_144_SPI_TR_Byte(0x28);
    LCD_144_SPI_TR_Byte(0x26);
    LCD_144_SPI_TR_Byte(0x2E);
    LCD_144_SPI_TR_Byte(0x3A);
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(0x01);
    LCD_144_SPI_TR_Byte(0x03);
    LCD_144_SPI_TR_Byte(0x13);
    
    LCD_144_CMD;                //写指令
    LCD_144_SPI_TR_Byte(0xE1);
    LCD_144_DATA;               //写数据
    LCD_144_SPI_TR_Byte(0x04);
    LCD_144_SPI_TR_Byte(0x16);
    LCD_144_SPI_TR_Byte(0x06);
    LCD_144_SPI_TR_Byte(0x0D);
    LCD_144_SPI_TR_Byte(0x2D);
    LCD_144_SPI_TR_Byte(0x26);
    LCD_144_SPI_TR_Byte(0x23);
    LCD_144_SPI_TR_Byte(0x27);
    LCD_144_SPI_TR_Byte(0x27);
    LCD_144_SPI_TR_Byte(0x25);
    LCD_144_SPI_TR_Byte(0x2D);
    LCD_144_SPI_TR_Byte(0x3B);
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(0x01);
    LCD_144_SPI_TR_Byte(0x04);
    LCD_144_SPI_TR_Byte(0x13);
    
    /*------End ST7735S Gamma Sequence------*/
    LCD_144_CMD;                //写指令
    LCD_144_SPI_TR_Byte(0x3A);  //65k mode
    LCD_144_DATA;               //写数据
    LCD_144_SPI_TR_Byte(0x05);
    LCD_144_CMD;                //写指令
    LCD_144_SPI_TR_Byte(0x29);  //Display on
    
    LCD_144_CS_1;               //取消片选ST7735S
}

/**
  * @brief  初始化LCD(ST7735S主控)工作状态
  * @note   None
  * @param  None
  * @retval None
  */
void LCD_144_Init(LCD_144_COLOR Color)
{
    LCD_144_Reset();            //软件复位
    LCD_144_Mode_Config();      //配置ST7735S工作参数
    LCD_144_Full_Display(Color);//全屏填充背景色

#if LCD_144_BL_PORT
    LCD_144_BL_ON;              //开启LCD背光
#endif  /** LCD_144_BL_PORT **/
}

/**
  * @brief  设置LCD显示区域
  * @note   在显示区域内可写入RGB565颜色信息，超出一行自动换行
  * @param  x_start:行起始坐标
            y_start:列起始坐标
            x_end:行终止坐标
            y_end:列终止坐标
  * @retval None
  */
void LCD_144_SetRegion(uint8_t x_start, uint8_t y_start, uint8_t x_end, uint8_t y_end)
{
    LCD_144_CS_0;           //片选ST7735S
    
    /* 根据显示方向调整显示区域起始地址(模块内部x,y两轴显示区域偏移值不同) */
#if LCD_144_DISPLAY_DIRECTION == LCD_144_DISPLAY_TOP        //排针在上
    LCD_144_CMD;
    LCD_144_SPI_TR_Byte(0x2a);   
    LCD_144_DATA;
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(x_start);
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(x_end - 1);
    LCD_144_CMD;
    LCD_144_SPI_TR_Byte(0x2b);
    LCD_144_DATA;
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(y_start + 32);
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(y_end + 31);
    
#elif LCD_144_DISPLAY_DIRECTION == LCD_144_DISPLAY_DOWN     //排针在下
    LCD_144_CMD;
    LCD_144_SPI_TR_Byte(0x2a);   
    LCD_144_DATA;
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(x_start);
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(x_end - 1);
    LCD_144_CMD;
    LCD_144_SPI_TR_Byte(0x2b);
    LCD_144_DATA;
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(y_start);
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(y_end - 1);
    
#elif LCD_144_DISPLAY_DIRECTION == LCD_144_DISPLAY_LEFT     //排针在左
    LCD_144_CMD;
    LCD_144_SPI_TR_Byte(0x2a);   
    LCD_144_DATA;
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(x_start + 32);
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(x_end + 31);
    LCD_144_CMD;
    LCD_144_SPI_TR_Byte(0x2b);
    LCD_144_DATA;
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(y_start);
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(y_end - 1);
    
#elif LCD_144_DISPLAY_DIRECTION == LCD_144_DISPLAY_RIGHT    //排针在右
    LCD_144_CMD;
    LCD_144_SPI_TR_Byte(0x2a);   
    LCD_144_DATA;
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(x_start);
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(x_end - 1);
    LCD_144_CMD;
    LCD_144_SPI_TR_Byte(0x2b);
    LCD_144_DATA;
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(y_start);
    LCD_144_SPI_TR_Byte(0x00);
    LCD_144_SPI_TR_Byte(y_end - 1); 
#endif  /*LCD_144_DISPLAY_DIRECTION*/

    LCD_144_CMD;
    LCD_144_SPI_TR_Byte(0x2c);
    LCD_144_DATA;    //数据流切换为写入数据
    
    LCD_144_CS_1;       //取消片选ST7735S
}

/**
  * @brief  在屏幕指定区域填充颜色
  * @note   None
  * @param  color:填充的颜色，x_start:x起始坐标，y_start:y起始坐标，x_end:x结束坐标，y_end:y结束坐标
  * @retval None
  */
void LCD_144_Part_Display(LCD_144_COLOR color, uint8_t x_start, uint8_t y_start, uint8_t x_offset, uint8_t y_offset)
{
    uint8_t i, m;
    
    /* 设置显示区域 */
    LCD_144_SetRegion(x_start, y_start, (x_start + x_offset), (y_start+ y_offset));
    
    /* 在显示区域填充颜色 */
    LCD_144_CS_0;       //片选ST7735S
    for(i = 0; i < x_offset; i++)
    {
        for(m = 0; m < y_offset; m++)
        {
             LCD_144_SPI_TR_Byte((uint8_t)(color>>8));   //颜色高字节(RGB565)
             LCD_144_SPI_TR_Byte((uint8_t)color);        //颜色低字节(RGB565)
        }
    }
    LCD_144_CS_1;       //取消片选ST7735S
}

/**
  * @brief  全屏填充指定的颜色
  * @note   可做清屏使用
  * @param  color:填充全屏像素的颜色
  * @retval None
  */
void LCD_144_Full_Display(LCD_144_COLOR color)
{
    uint8_t i, m;
    
    /* 设置显示区域 */
    LCD_144_SetRegion(0, 0, LCD_144_PIXEL_X, LCD_144_PIXEL_Y);
    
    /* 在显示区域填充颜色 */
    LCD_144_CS_0;       //片选ST7735S
    for(i = 0; i < LCD_144_PIXEL_X; i++)
    {
        for(m = 0; m < LCD_144_PIXEL_Y; m++)
        {
             LCD_144_SPI_TR_Byte((uint8_t)(color>>8));   //颜色高字节(RGB565)
             LCD_144_SPI_TR_Byte((uint8_t)color);        //颜色低字节(RGB565)
        }
    }
    LCD_144_CS_1;       //取消片选ST7735S
}

/**
  * @brief  发送字模的颜色数据
  * @note   字模数据bit[7:0]分别对应一个像素点，每个像素点颜色分为高低两字节，所以一字节字模数据需要发送16字节数据
  * @param  *txbuf：发送的字模颜色数据
  *         *rxbuf：MISO接口采样到的数据(无意义，可忽略，配置只是程序需要)(LCD模块未引出ST7735S的数据输出接口)
  * @retval None
  */
void LCD_144_DMA_Config(uint8_t *txbuf, uint8_t *rxbuf)
{
    LCD_144_SPI_DMA_TX->MADDR = (uint32_t)txbuf;    //设置SPIx_DMA_TX存储器地址(地址未更改不用重新配置)
    LCD_144_SPI_DMA_RX->MADDR = (uint32_t)rxbuf;    //设置SPIx_DMA_RX存储器地址(地址未更改不用重新配置)
    LCD_144_SPI_DMA_RX->CFGR &= (uint16_t)0xff7f;   //使能SPIx_DMA_RX接收存储器地址指针不递增
}

/**
  * @brief  启动SPI DMA向ST7735S发送点阵颜色数据
  * @note   None
  * @param  p_cnt:本次需要发送的字模数据数量
  * @retval None
  */
void LCD_144_DMA_Send_Pixel_Data(uint16_t p_cnt)
{
    uint16_t count = 60000;                         //超时计数变量
    LCD_144_CS_0;                                   //片选1.44" LCD(ST7735S)
    LCD_144_SPI_DMA_TX->CNTR = p_cnt;              //设置SPIx_DMA_TX传输数据个数
    LCD_144_SPI_DMA_RX->CNTR = p_cnt;              //设置SPIx_DMA_RX接收数据个数
    LCD_144_SPI_DMA_TX->CFGR |= (uint16_t)0x0001;    //使能SPIx_DMA_TX开始发送数据
    LCD_144_SPI_DMA_RX->CFGR |= (uint16_t)0x0001;    //使能SPIx_DMA_RX开始接收数据
    while(!(LCD_144_SPI->STATR & SPI_I2S_FLAG_TXE) && --count);    //等待SPI_SR状态寄存器TXE=1(写入SPI_DR的最后一个数据开始传输)
    count = 60000;                                  //重置计数值
    while((LCD_144_SPI->STATR & SPI_I2S_FLAG_BSY) && --count);     //等待SPI_SR状态寄存器BSY=0(数据传输完成)
    LCD_144_CS_1;                                   //取消片选1.44" LCD(ST7735S)
}

//定义来源是Flash的字模参数结构体变量并赋值
LCD_144_FONT LCD_144_ASCII_8x16 = {
  8,    /* Width */
  16,   /* Height */
  16   /* Offset */
};

LCD_144_FONT LCD_144_CHN_16x16 = {
  16,   /* Width */
  16,   /* Height */
  32   /* Offset */
};

LCD_144_FONT LCD_144_ASCII_16x24 = {
  16,   /* Width */
  24,   /* Height */
  48   /* Offset */
};

LCD_144_FONT LCD_144_CHN_24x24 = {
  24,   /* Width */
  24,   /* Height */
  72   /* Offset */
};
