#ifndef __1_44_ST7735S_H
#define __1_44_ST7735S_H

#include "ch32v20x.h"

/* LCD连接的SPI总线 */
#if 1   //(1:使用SPI1,0:使用SPI2)
  #define LCD_144_SPI         SPI1
  #define LCD_144_SPI_DMA_TX  DMA1_Channel3
  #define LCD_144_SPI_DMA_RX  DMA1_Channel2
#else
  #define LCD_144_SPI         SPI2
  #define LCD_144_SPI_DMA_TX  DMA1_Channel5
  #define LCD_144_SPI_DMA_RX  DMA1_Channel4
#endif

/* LCD显示方向(排针朝向) */
#define LCD_144_DISPLAY_DIRECTION   LCD_144_DISPLAY_TOP
#define LCD_144_DISPLAY_TOP     1
#define LCD_144_DISPLAY_DOWN    2
#define LCD_144_DISPLAY_LEFT    3
#define LCD_144_DISPLAY_RIGHT   4

/* LCD显示像素范围(1.44"LCD显示像素范围128x128) */
#define LCD_144_PIXEL_X     128
#define LCD_144_PIXEL_Y     128

/* LCD控制引脚(ReSet(复位),D/C(指令/数据流控制),CS(片选),BL(背光))工作模式宏定义 */
#define LCD_144_RST_PORT    1   //初始化连接到LCD模块RST引脚上的单片机IO工作模式(1:初始化,0:悬空)
#define LCD_144_DC_PORT     1   //初始化连接到LCD模块D/C引脚上的单片机IO工作模式(1:初始化,0:悬空)
#define LCD_144_CS_PORT     1   //初始化连接到LCD模块CS引脚上的单片机IO工作模式(1:初始化,0:悬空)
#define LCD_144_BL_PORT     1   //初始化连接到LCD模块BL引脚上的单片机IO工作模式(1:初始化,0:悬空)

/***RST引脚宏定义***/
#if LCD_144_RST_PORT
  #define LCD_144_RST_CLK    RCC_APB2Periph_GPIOC
  #define LCD_144_RST_Port   GPIOC
  #define LCD_144_RST_Pin    GPIO_Pin_2

  /**以下宏定义无需修改**/
  #define LCD_144_RST_L      LCD_144_RST_Port->BCR = LCD_144_RST_Pin    //输出低电平(低电平有效)
  #define LCD_144_RST_H      LCD_144_RST_Port->BSHR = LCD_144_RST_Pin   //输出高电平
#endif  /** LCD_144_RST_PORT **/

/***数据/指令流控制引脚宏定义***/
#if LCD_144_DC_PORT
  #define LCD_144_DC_CLK    RCC_APB2Periph_GPIOC
  #define LCD_144_DC_Port   GPIOC
  #define LCD_144_DC_Pin    GPIO_Pin_3

  /**以下宏定义无需修改**/
  #define LCD_144_CMD       LCD_144_DC_Port->BCR = LCD_144_DC_Pin       //选择输出命令流(低电平)
  #define LCD_144_DATA      LCD_144_DC_Port->BSHR = LCD_144_DC_Pin      //选择输出数据流(高电平)
#endif  /** LCD_144_DC_PORT **/

/***背光控制引脚宏定义***/
#if LCD_144_CS_PORT
  #define LCD_144_CS_CLK    RCC_APB2Periph_GPIOC
  #define LCD_144_CS_Port   GPIOC
  #define LCD_144_CS_Pin    GPIO_Pin_4

  /**以下宏定义无需修改**/
  #define LCD_144_CS_0      LCD_144_CS_Port->BCR = LCD_144_CS_Pin       //使能片选(低电平)
  #define LCD_144_CS_1      LCD_144_CS_Port->BSHR = LCD_144_CS_Pin      //取消片选(高电平)
#endif  /** LCD_144_CS_PORT **/

/***背光控制引脚宏定义***/
#if LCD_144_BL_PORT
  #define LCD_144_BL_CLK    RCC_APB2Periph_GPIOC
  #define LCD_144_BL_Port   GPIOC
  #define LCD_144_BL_Pin    GPIO_Pin_5

  /**以下宏定义无需修改**/
  #define LCD_144_BL_OFF    LCD_144_BL_Port->BCR = LCD_144_BL_Pin       //关闭背光(低电平)
  #define LCD_144_BL_ON     LCD_144_BL_Port->BSHR = LCD_144_BL_Pin      //开启背光(高电平)
#endif  /** LCD_144_BL_PORT **/

typedef enum {
    LCD_144_RED     = 0xF800,   //红色
    LCD_144_GREEN   = 0x07E0,   //绿色
    LCD_144_YELLOW  = 0xFFE0,   //黄色
    LCD_144_ORANGE  = 0xFD20,   //橙色
    LCD_144_PURPLE  = 0xF81F,   //紫色
    LCD_144_BLUE    = 0x051F,   //蓝色
    LCD_144_CYAN    = 0x7FFF,   //青色
    LCD_144_BLACK   = 0x0000,   //黑色
    LCD_144_WHITE   = 0xFFFF    //白色
}LCD_144_COLOR;                 //LCD显示颜色枚举类型

typedef struct {    
  uint8_t Width;                //字符宽度
  uint8_t Height;               //字符高度
  uint8_t Offset;               //字符字模数据个数
}LCD_144_FONT;                  //flash存储的字模参数结构体类型

extern LCD_144_FONT LCD_144_ASCII_8x16; //定义ASCII码8x16字模参数结构体变量
extern LCD_144_FONT LCD_144_CHN_16x16;  //定义GB2312字符16x16字模参数结构体变量
extern LCD_144_FONT LCD_144_ASCII_16x24;//定义ASCII码16x24字模参数结构体变量
extern LCD_144_FONT LCD_144_CHN_24x24;  //定义ASCII码24x24字模参数结构体变量

typedef enum {    
    LCD_144_Mix_FONT_16H = 16,          //字符高度
    LCD_144_Mix_FONT_24H = 24           //字符高度
}LCD_144_Mix_FONT;                      //flash存储的字模参数结构体类型

/********************* 功能函数 *********************/
void LCD_144_Ctrl_Init(void);
void LCD_144_Init(LCD_144_COLOR Color);
void LCD_144_SetRegion(uint8_t x_start, uint8_t y_start, uint8_t x_end, uint8_t y_end);
void LCD_144_Part_Display(LCD_144_COLOR color, uint8_t x_start, uint8_t y_start, uint8_t x_offset, uint8_t y_offset);
void LCD_144_Full_Display(LCD_144_COLOR color);

void LCD_144_DMA_Config(uint8_t *txbuf, uint8_t *rxbuf);
void LCD_144_DMA_Send_Pixel_Data(uint16_t p_cnt);

#endif  /* __1_44_ST7735S_H */
