#include "aht21b.h"

/**
  * @brief  检查AHT21B所在IIC总线的通讯状态
  * @note   None
  * @param  I2C_EVENT：I2C总线事件
  * @retval SUCCESS(获取事件状态成功)；ERROR(获取事件状态失败)
  */
static ErrorStatus AHT21B_CheckEvent(uint32_t I2C_EVENT)
{
    uint16_t timeout = 10000;       //检查事件次数
    uint32_t flag1 = 0, flag2 = 0;

    do {
    /* 读取I2C状态寄存器的值 */
    flag1 = AHT21B_I2C->STAR1;
    flag2 = AHT21B_I2C->STAR2;
    flag2 = flag2 << 16;

    /* 合并两个寄存器的值 */
    flag2 = (flag1 | flag2) & (uint32_t)0x00FFFFFF;
    } while(((flag2 & I2C_EVENT) != I2C_EVENT) && --timeout);

    /* 如非超时退出，则返回获取事件成功；否则返回获取事件失败 */
    if (timeout) {
        return READY;
    }
    else {
        AHT21B_I2C->CTLR1 |= (uint16_t)0x0200;  //置位bit9:STOP位(在传输完当前数据后生停止位)
        return NoREADY;
    }
}

/**
  * @brief  将一字节数据或指令写入IIC数据寄存器,并等待数据移至移位寄存器(EV8,TxE=1)
  * @note   None
  * @param  data：待写入的数据或指令
  * @retval None
  */
static void AHT21B_IIC_Send_Byte(uint8_t data)
{
    AHT21B_I2C->DATAR = data;
    AHT21B_CheckEvent(I2C_EVENT_MASTER_BYTE_TRANSMITTING);
}

/**
  * @brief  向AHT21B连续发送指令
  * @note   None
  * @param  *pbuf：发送的指令
  *         cnt：发送指令的数量
  * @retval IIC通信状态:1标识发送数据或指令成功，非1标识IIC通信过程出错
  */
static uint8_t AHT21B_Send_Command(uint8_t *pbuf, uint8_t cnt)
{
    /* 1.发送起始信号，等待起始信号发出(EV5事件) */
    AHT21B_I2C->CTLR1 |= (uint16_t)0x0100;  //I2C_GenerateSTART(AHT21B_I2C, ENABLE);
    if(AHT21B_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT) == NoREADY) {
        return 3;
    }

    /* 2.向总线发送从机地址，等待从机ACK(ADDR位置位)，读取状态寄存器SR1和SR2将ADDR位清零(EV6事件) */
    AHT21B_I2C->DATAR = AHT21B_ADDR_W;      //I2C_Send7bitAddress(AHT21B_I2C, MPU6050_ADDR_W, I2C_Direction_Transmitter);
    if(AHT21B_CheckEvent(I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED) == NoREADY) {
        return 2;
    }

    /* 3.连续发送指令 */
    while(cnt) {
        AHT21B_IIC_Send_Byte(*pbuf); pbuf++; cnt--;
    }
    
    /* 4.置位bit9:STOP位(在传输完当前数据后生停止位) */
    AHT21B_I2C->CTLR1 |= (uint16_t)0x0200;

    return 1;
}

/**
  * @brief  获取AHT21B当前状态
  * @note   None
  * @param  None
  * @retval AHT21B状态寄存器值
  */
static uint8_t AHT21B_Get_Status(void)
{ 
    /* 1.发送起始信号,等待起始信号发出(EV5事件);置位bit10:ACK位(在接收一个字节匹配地址或数据之后返回应答) */
    AHT21B_I2C->CTLR1 |= (uint16_t)0x0500;  //I2C_GenerateSTART(AHT21B_I2C, ENABLE);
    if(AHT21B_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT) == NoREADY) {
        return 0;
    }    

    /* 2.向总线发送从机地址,等待从机ACK(ADDR位置位),读取状态寄存器SR1和SR2将ADDR位清零(EV6事件);复位bit10:ACK位,接收当前字节后发送NACK */
    AHT21B_I2C->DATAR = AHT21B_ADDR_R;      //I2C_Send7bitAddress(AHT21B_I2C, MPU6050_ADDR_R, I2C_Direction_Receiver);
    AHT21B_I2C->CTLR1 &= (uint16_t)0xfbff;  //I2C_AcknowledgeConfig(AHT21B_I2C, DISABLE);
    if(AHT21B_CheckEvent(I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED) == NoREADY) {
        return 0;
    }
    
    /* 3.置位bit9:STOP位(在传输完当前数据后生停止位) */
    AHT21B_I2C->CTLR1 |= (uint16_t)0x0200;

    /* 4.等待EV7，RxNE(数据寄存器非空)，读取IIC数据寄存器的值 */
    if(AHT21B_CheckEvent(I2C_EVENT_MASTER_BYTE_RECEIVED) == NoREADY) {
        return 0;
    }
    return AHT21B_I2C->DATAR;
}

/**
  * @brief  接收AHT21B发回的7字节数据(1字节状态值+5字节温湿度测量值+1字节CRC8校验值)
  * @note   None
  * @param  *data：接收到的数据
  * @retval IIC通信状态:1标识接收数据成功,非1标识通信过程出错
  */
static uint8_t AHT21B_Read_Data(uint8_t *data)
{ 
    uint8_t i; 
    
    /* 1.发送起始信号,等待起始信号发出(EV5事件);置位bit10:ACK位(在接收一个字节匹配地址或数据之后返回应答) */
    AHT21B_I2C->CTLR1 |= (uint16_t)0x0500;  //I2C_GenerateSTART(AHT21B_I2C, ENABLE);
    if(AHT21B_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT) == NoREADY) {
        return 6;
    }
        
    /* 2.向总线发送从机地址,等待从机ACK(ADDR位置位),读取状态寄存器SR1和SR2将ADDR位清零(EV6事件) */
    AHT21B_I2C->DATAR = AHT21B_ADDR_R;
    if(AHT21B_CheckEvent(I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED) == NoREADY) {
        return 5;
    }
    
    /* 3.接收AHT21B发回的前5字节数据 */
    for(i = 0; i < 5; i++)
    {
        /* 等待EV7，RxNE(数据寄存器非空)，读取IIC数据寄存器的值 */
        if(AHT21B_CheckEvent(I2C_EVENT_MASTER_BYTE_RECEIVED) == NoREADY) {
            return 4;
        }
        *data = AHT21B_I2C->DATAR;          //读取接收到的测量数据
        data++;                             //指向下一个数据存放的地址
    }
                      
    /* 4.接收AHT21B发送的第6字节数据(EV7:RxNE(数据寄存器非空);复位ACK位,在接收当前数据之后NACK */
    if(AHT21B_CheckEvent(I2C_EVENT_MASTER_BYTE_RECEIVED) == NoREADY) {
        return 3;
    }
    AHT21B_I2C->CTLR1 &= (uint16_t)0xfbff;  //复位ACK位(在接收一个字节(匹配地址或数据)之后NACK)
    *data = AHT21B_I2C->DATAR;              //接收第6字节数据
    data++;                                 //指向下一个数据存放的地址

    /* 5.置位bit9:STOP位(在传输完当前数据后生停止位) */
    AHT21B_I2C->CTLR1 |= (uint16_t)0x0200;

    /* 6.接收AHT21B发送的第7字节数据(EV7:RxNE(数据寄存器非空) */
    if(AHT21B_CheckEvent(I2C_EVENT_MASTER_BYTE_RECEIVED) == NoREADY) {
        return 2;
    }
    *data = AHT21B_I2C->DATAR;              //接收第7字节数据
    return 1;                               //标识接收数据成功
}

/**
  * @brief  计算接收到AHT21B测量的数据的CRC8校验值
  * @note   计算多项式：X8+X5+X4+1
  * @param  *value：1字节状态值+5字节温湿度数据
  * @retval 接收到的数据CRC8校验计算结果
  */
static uint8_t AHT21B_Calc_CRC8_Value(uint8_t *value)
{
    uint8_t i, j;           //临时变量
    uint8_t crc = 0xff;     //AHT21B CRC初始值为0XFF
    for(i = 0; i < 6; i++)
    {
        crc = crc ^ value[i];
        for(j = 0; j < 8; j++)
        {
            if(crc & 0x80) {
                crc = crc << 1;
                crc = crc ^ (uint8_t)0x31;
            }
            else {
                crc = crc << 1;
            }
        }
    }
    return crc;
}

/**
  * @brief  将接收到的5字节湿度、温度数据分别合并成20bit数据
  * @note   None
  * @param  *measured_value：合并后的20bit温湿度数据
  *         *value：从AHT21B接收到的温湿度原始数据
  * @retval None
  */
static void AHT21B_Merge_Measured_value(int32_t *measured_value, uint8_t *value)
{
    measured_value[0] |= (int32_t)value[1];
    measured_value[0] <<= 8;
    measured_value[0] |= (int32_t)value[2];
    measured_value[0] <<= 8;
    measured_value[0] |= (int32_t)value[3];
    measured_value[0] >>= 4;                    //湿度数据
    
    measured_value[1] |= (int32_t)value[3];
    measured_value[1] <<= 8;
    measured_value[1] |= (int32_t)value[4];
    measured_value[1] <<= 8;
    measured_value[1] |= (int32_t)value[5];
    measured_value[1] &= (int32_t)0x000fffff;   //温度数据
}

/**
  * @brief  检查AHT21B上电初始化状态
  * @note   如果状态异常，则重新初始化
  * @param  None
  * @retval 1：上电初始化正常；2：发送重新初始化命令出错；3：发送重新初始化命令成功
  */
uint8_t AHT21B_Init(void)
{
    uint8_t status = 0;
    uint8_t aht21b_init_cmd[3] = {AHT21B_INIT_COMMAND1, AHT21B_INIT_COMMAND2, AHT21B_INIT_COMMAND3};
    status = AHT21B_Get_Status();                           //获取AHT21B当前状态寄存器的值
    if((status & AHT21B_Status_OK) != AHT21B_Status_OK)     //如果获取的状态值bit4、bit3不为1则重新初始化AHT21B
    {
        if(AHT21B_Send_Command(aht21b_init_cmd, 3) == 1) {
            return 3;   //重新初始化命令发送成功
        }
        else {
            return 2;   //重新初始化命令发送失败
        }                
    }
    return 1;           //上电初始化正常
}

/**
  * @brief  向AHT21B发送开始测量命令
  * @note   None
  * @param  None
  * @retval 1：发送命令成功；非0：发送命令出错
  */
uint8_t AHT21B_Start_Measure(void)
{
    uint8_t aht21b_measure_cmd[3] = {AHT21B_START_MEASURE, AHT21B_MEASURE_CODE1, AHT21B_MEASURE_CODE2};
    return AHT21B_Send_Command(aht21b_measure_cmd, 3);
}

/**
  * @brief  读取AHT21B测量的温湿度值和CRC8校验值，并进行CRC8校核计算，分别合并温湿度两个值为20bit数据
  * @note   None
  * @param  *measured_value：温湿度数据(20bit)
  * @retval 3：读取数据成功，CRC8校验计算正确；2：读取数据成功，CRC8校验失败；1：读取数据出错；0：转换值未就绪
  */
uint8_t AHT21B_Get_Measured_Value(int32_t *measured_value)
{
    uint8_t status = 0;
    uint8_t aht_data[7];    //暂存从AHT21B读出的7个字节数据
    measured_value[0] = 0; measured_value[1] = 0;   //清除上一轮的测量值，IIC通讯异常返回0亦可做标识
    status = AHT21B_Get_Status();
    if((status & (uint8_t)0x80) == 0)
    {
        /* 读取AHT21B转换的温湿度和CRC校验数据(1字节状态值+5字节温湿度数据+1字节CRC校验值) */
        status = AHT21B_Read_Data(aht_data);
        if(status == 1)     //从AHT21B接收数据成功
        {
            /* 计算接收到的数据的CRC8校验值 */
            status = AHT21B_Calc_CRC8_Value(aht_data);
            if(status == aht_data[6])   //CRC8校验计算值与接收到的校验值一致
            {
                /* 将接收到的原始测量数据合并为20bit数据 */
                AHT21B_Merge_Measured_value(measured_value, aht_data);
                return 3;   //AHT21B当前空闲，读取数据成功，CRC8校验计算正确
            }
            else 
            {
                return 2;   //AHT21B当前空闲，读取数据成功，CRC8校验失败
            }
        }
        else 
        {
            return 1;       //AHT21B当前空闲，读取数据出错
        }        
    }
    return 0;               //AHT21B当前忙，转换值未就绪
}

/**
  * @brief  将AHT21B测量的温度原始数据转为ASCII码
  * @note   None
  * @param  raw_data:AHT21B测量的温度数据
  *         Temp_str:本次转换的显示数据存储地址
  * @retval None
  */
uint8_t AHT21B_T_Raw_Data_Transform(int32_t *raw_data, uint8_t *Temp_str)
{
    uint8_t cnt = 0, temp_data;

    if(*raw_data < 0x40000)     //判断温度是否为负(50 / 200 * 2^20 = 262144，测量值小于此值则温度为负)
    {
        /*将实际值放大100倍,再强制类型转换为整数，实现保留两位小数*/
        *raw_data = (float)(*raw_data) * 20000 / 1048576;
        *raw_data = 5000 - *raw_data;

        /*将'-'ASCII码写入显示缓存数组*/
        Temp_str[0] = '-';

        /*将计算值按低位到高位分离并存至缓存数组*/
        do {
            cnt++;
            Temp_str[cnt] = *raw_data % 10;
            *raw_data /= 10;
        } while(*raw_data);

        /*根据测量值选择对应的处理方案*/
        switch(cnt) {
            case 4:                             //温度为-ab.cd(交换前为'-'dcba)
            {
                temp_data = Temp_str[1] + 48;   //缓存d,并换算成对应ASCII码'd'
                Temp_str[1] = Temp_str[4] + 48; //将a换算成'a'并存至第一个整数位('-''a'cba)
                Temp_str[5] = temp_data;        //将'd'存至小数点后第二位('-''a'cba'd')
                temp_data = Temp_str[2] + 48;   //缓存c,并换算成对应ASCII码'c'
                Temp_str[2] = Temp_str[3] + 48; //将b换算成'b'并存至第二个整数位('-''a''b'ba'd')
                Temp_str[4] = temp_data;        //将'c'存至小数点后第一位('-''a''b'b'c''d')
                Temp_str[3] = '.';              //将小数点置于第二位整数后('-''a''b''.''c''d')
                Temp_str[6] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[7] = 0xE6;
                cnt = 6;
                break;
            }
            case 3:                             //温度为-a.bc(交换前为'-'cba)
            {
                temp_data = Temp_str[1] + 48;   //缓存c,并换算成对应ASCII码'c'
                Temp_str[1] = Temp_str[3] + 48; //将a换算成'a'并存至第一个整数位('-''a'ba)
                Temp_str[3] = Temp_str[2] + 48; //将b换算成'b'并存至小数点后第一位('-''a'b'b')
                Temp_str[4] = temp_data;        //将'c'存至小数点后第二位('-''a'b'b''c')
                Temp_str[2] = '.';              //将小数点置于整数后('-''a''.''b''c')
                Temp_str[5] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[6] = 0xE6;
                cnt = 5;
                break;
            }
            case 2:                             //温度为-0.ab(交换前为'-'ba)
            {
                Temp_str[4] = Temp_str[1] + 48; //将b换算成'b'并存至小数点后第二位('-'ba 'b')
                Temp_str[3] = Temp_str[2] + 48; //将a换算成'a'并存至小数点后第一位('-'ba'a''b')
                Temp_str[1] = '0';              //补'0'('-''0'a'a''b')
                Temp_str[2] = '.';              //将小数点置于'0'后('-''0''.''a''b')
                Temp_str[5] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[6] = 0xE6;
                cnt = 5;
                break;
            }
            case 1:                             //温度为-0.0a(交换前为'-'a)
            {
                Temp_str[4] = Temp_str[1] + 48; //将a换算成'a'并存至小数点后第二位('-'a  'a')
                Temp_str[1] = '0';              //补'0'('-''0'  'a')
                Temp_str[2] = '.';              //将小数点置于'0'后('-''0''.' 'a')
                Temp_str[3] = '0';              //小数点后补'0'(('-''0''.''0''a') )
                Temp_str[5] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[6] = 0xE6;
                cnt = 5;
                break;
            }
            default :                           //无效值
            {
                Temp_str[0] = 'N';
                Temp_str[1] = 'U';
                Temp_str[2] = 'L';
                Temp_str[3] = 'L';
                cnt = 0;
                break;
            }
        }
    }
    else                                        //测量温度为正的处理方式
    {
        /*将实际值放大100倍,再强制类型转换为整数，实现保留两位小数*/
        *raw_data = (float)(*raw_data) * 20000 / 1048576;
        *raw_data = *raw_data - 5000;

        /*将计算值按位(从低位位到高位)分离并存至缓存数组*/
        do {
            Temp_str[cnt] = *raw_data % 10;
            *raw_data /= 10;
            cnt++;
        } while(*raw_data);

        /*根据测量值选择对应的处理方案*/
        switch(cnt) {
            case 5:                             //温度为abc.de(交换前为edcba)
            {
                temp_data = Temp_str[0] + 48;   //缓存e,并换算成对应ASCII码'e'
                Temp_str[0] = Temp_str[4] + 48; //将a换算成'a'并存至第一个整数位('a'dcba)
                Temp_str[5] = temp_data;        //将'e'存至小数点后第二位('a'dcba'e')
                temp_data = Temp_str[1] + 48;   //缓存d,并换算成对应ASCII码'd'
                Temp_str[1] = Temp_str[3] + 48; //将b换算成'b'并存至第二个整数位('a''b'cba'e')
                Temp_str[4] = temp_data;        //将'd'存至小数点后第一位('a''b'cb'd''e')
                Temp_str[2] = Temp_str[2] + 48; //将c换算成'c'并存至第三个整数位('a''b''c'b'd''e')
                Temp_str[3] = '.';              //将小数点置于第二位整数后('a''b''c''.''d''e')
                Temp_str[6] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[7] = 0xE6;
                cnt = 6;
                break;
            }
            case 4:                             //温度为ab.cd(交换前为dcba)
            {
                temp_data = Temp_str[0] + 48;   //缓存d,并换算成对应ASCII码'd'
                Temp_str[0] = Temp_str[3] + 48; //将a换算成'a'并存至第一个整数位('a'cba)
                Temp_str[4] = temp_data;        //将'd'存至小数点后第二位('a'cba'd')
                temp_data = Temp_str[1] + 48;   //缓存c,并换算成对应ASCII码'c'
                Temp_str[1] = Temp_str[2] + 48; //将b换算成'b'并存至第二个整数位('a''b'ba'd')
                Temp_str[3] = temp_data;        //将'c'存至小数点后第一位('a''b'b'c''d')
                Temp_str[2] = '.';              //将小数点置于第二位整数后('a''b''.''c''d')
                Temp_str[5] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[6] = 0xE6;
                cnt = 5;
                break;
            }
            case 3:                             //温度为a.bc(交换前为cba)
            {
                temp_data = Temp_str[0] + 48;   //缓存c,并换算成对应ASCII码'c'
                Temp_str[0] = Temp_str[2] + 48; //将a换算成'a'并存至第一个整数位('a'ba)
                Temp_str[2] = Temp_str[1] + 48; //将b换算成'b'并存至小数点后第一位('a'b'b')
                Temp_str[3] = temp_data;        //将'c'存至小数点后第二位('a'b'b''c')
                Temp_str[1] = '.';              //将小数点置于整数后('a''.''b''c')
                Temp_str[4] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[5] = 0xE6;
                cnt = 4;
                break;
            }
            case 2:                             //温度为0.ab(交换前为ba)
            {
                Temp_str[3] = Temp_str[0] + 48; //将b换算成'b'并存至小数点后第二位(ba 'b')
                Temp_str[2] = Temp_str[1] + 48; //将a换算成'a'并存至小数点后第一位(ba'a''b')
                Temp_str[0] = '0';              //补'0'('0'a'a''b')
                Temp_str[1] = '.';              //将小数点置于'0'后('0''.''a''b')
                Temp_str[4] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[5] = 0xE6;
                cnt = 4;
                break;
            }
            case 1:                            //温度为0.0a(交换前为a)
            {
                Temp_str[3] = Temp_str[0] + 48; //将a换算成'a'并存至小数点后第二位(a  'a')
                Temp_str[0] = '0';              //补'0' ('0'  'a')
                Temp_str[1] = '.';              //将小数点置于'0'后('0''.' 'a')
                Temp_str[2] = '0';              //小数点后补'0'('0''.''0''a')
                Temp_str[4] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[5] = 0xE6;
                cnt = 4;
                break;
            }
            default :                           //测量值无效
            {
                Temp_str[0] = 'N';
                Temp_str[1] = 'U';
                Temp_str[2] = 'L';
                Temp_str[3] = 'L';
                cnt = 0;
                break;
            }
        }
    }
    return cnt;                                 //返回测量值位数(含小数点)
}

/**
  * @brief  将AHT21B测量的相对湿度原始数据转为ASCII码
  * @note   None
  * @param  raw_data:AHT21B测量的相对湿度数据
  *         Temp_str:本次转换的显示数据存储地址
  * @retval None
  */
uint8_t AHT21B_H_Raw_Data_Transform(int32_t *raw_data, uint8_t *Temp_str)
{
    uint8_t cnt = 0, temp_data;

    /*使用原始测量值计算的相对湿度值为小数，将实际值放大1000倍，实现转换为百分制并保留一位小数*/
    *raw_data = (*raw_data) * 1000 / 1048576;

    /*将计算值按位(从低位位到高位)分离并存至缓存数组*/
    do {
        Temp_str[cnt] = *raw_data % 10;
        *raw_data /= 10;
        cnt++;
    } while(*raw_data);

    /*根据测量值选择对应的处理方案*/
    switch(cnt) {
        case 4:                             //相对湿度为abc(100%)(交换前为dcba)（理论上测试达不到100%）
        {
            Temp_str[0] = Temp_str[3] + 48; //将a换算成'a'并存至第一个整数位('a'cba)
            temp_data = Temp_str[1] + 48;   //缓存c,并换算成对应ASCII码'c'
            Temp_str[1] = Temp_str[2] + 48; //将b换算成'b'并存至第二个整数位('a''b'ba)
            Temp_str[2] = temp_data;        //将'c'存至第三个整数位('a''b''c'a)
            Temp_str[3] = 0xA3;             //将%置于第一位小数后('a''b''c''%')
            Temp_str[4] = 0xA5;             //％符号GBK编码
            Temp_str[5] = 'R';              //字符'R'
            Temp_str[6] = 'H';              //字符'H'
            cnt = 3;
            break;
        }
        case 3:                             //相对湿度为ab.c(交换前为cba)
        {
            temp_data = Temp_str[0] + 48;   //缓存c,并换算成对应ASCII码'c'
            Temp_str[0] = Temp_str[2] + 48; //将a换算成'a'并存至第一个整数位('a'ba)
            Temp_str[1] = Temp_str[1] + 48; //将b换算成'b'并存至第二个整数位('a''b'a)
            Temp_str[3] = temp_data;        //将'c'存至小数点后第一位('a''b'a'c')
            Temp_str[2] = '.';              //将小数点置于整数后('a''b''.''c')
            Temp_str[4] = 0xA3;             //将%置于第一位小数后(''a''b''.''c''%')
            Temp_str[5] = 0xA5;             //％符号GBK编码
            Temp_str[6] = 'R';              //字符'R'
            Temp_str[7] = 'H';              //字符'H'
            cnt = 4;
            break;
        }
        case 2:                             //相对湿度为a.b(交换前为ba)
        {
            temp_data = Temp_str[0] + 48;   //缓存b,并换算成对应ASCII码'b'
            Temp_str[0] = Temp_str[1] + 48; //将a换算成'a'并存至整数位('a'a)
            Temp_str[2] = temp_data;        //将b存至小数点后第一位('a'a'b')
            Temp_str[1] = '.';              //将小数点置于整数后('a''.''b')
            Temp_str[3] = 0xA3;             //将%置于第一位小数后('a''.''b''%')
            Temp_str[4] = 0xA5;             //％符号GBK编码
            Temp_str[5] = 'R';              //字符'R'
            Temp_str[6] = 'H';              //字符'H'
            cnt = 3;
            break;
        }
        case 1:                             //相对湿度为0.a(交换前为a)
        {
            temp_data = Temp_str[0] + 48;   //缓存a,并换算成对应ASCII码'a'
            Temp_str[0] = '0';              //首位补'0'
            Temp_str[1] = '.';              //添加小数点'.'
            Temp_str[2] = temp_data;        //将a换算成'a'并存至小数点后('0''.''a')
            Temp_str[3] = 0xA3;             //将%置于第一位小数后('0''.''a''%')
            Temp_str[4] = 0xA5;             //％符号GBK编码
            Temp_str[5] = 'R';              //字符'R'
            Temp_str[6] = 'H';              //字符'H'
            cnt = 3;
            break;
        }
        default :                           //无效值
        {
            Temp_str[0] = 'N';
            Temp_str[1] = 'U';
            Temp_str[2] = 'L';
            Temp_str[3] = 'L';
            cnt = 0;
            break;
        }
    }
    return cnt;                             //返回测量值位数(含小数点)
}
