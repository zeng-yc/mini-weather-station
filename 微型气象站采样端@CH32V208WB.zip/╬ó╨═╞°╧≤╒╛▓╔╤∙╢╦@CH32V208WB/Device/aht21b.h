#ifndef __AHT21B_H
#define __AHT21B_H

#include "ch32v20x.h"

#define AHT21B_I2C              I2C1    //MPU6050挂载的IIC总线
#define AHT21B_ADDR_W           0x70    //写操作
#define AHT21B_ADDR_R           0x71    //读操作

/* AHT21B已就绪状态值(发送读操作0x71获取) */
#define AHT21B_Status_OK        0x18    //AHT21B已就绪状态值(上电后第一次触发测量前校对)

/* AHT21B寄存器操作指令 */
#define AHT21B_INIT_COMMAND1    0x1B    //AHT21B初始化命令1
#define AHT21B_INIT_COMMAND2    0x1C    //AHT21B初始化命令2
#define AHT21B_INIT_COMMAND3    0x1E    //AHT21B初始化命令3
#define AHT21B_START_MEASURE    0xAC    //触发AHT21B开始转换命令
#define AHT21B_MEASURE_CODE1    0x33    //触发AHT21B转换参数
#define AHT21B_MEASURE_CODE2    0x00    //触发AHT21B转换参数

/*******************************************函数声明*******************************************/
uint8_t AHT21B_Init(void);
uint8_t AHT21B_Start_Measure(void);
uint8_t AHT21B_Get_Measured_Value(int32_t *measured_value);

uint8_t AHT21B_T_Raw_Data_Transform(int32_t *raw_data, uint8_t *Temp_str);
uint8_t AHT21B_H_Raw_Data_Transform(int32_t *raw_data, uint8_t *Temp_str);

#endif /* __AHT21B_H */
