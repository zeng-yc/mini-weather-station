#include "bmp280.h"

static BMP280_Trimming_Parameters_TypeDef BMP280_Parameters;    //定义BMP280补偿参数结构体变量

/**
  * @brief  检查BMP280所在IIC总线的通讯状态
  * @note   None
  * @param  I2C_EVENT：I2C总线事件
  * @retval SUCCESS(获取事件状态成功)；ERROR(获取事件状态失败)
  */
static ErrorStatus BMP280_CheckEvent(uint32_t I2C_EVENT)
{
    uint16_t timeout = 10000;       //检查事件次数
    uint32_t flag1 = 0, flag2 = 0;

    do {
    /* 读取I2C状态寄存器的值 */
    flag1 = BMP280_I2C->STAR1;
    flag2 = BMP280_I2C->STAR2;
    flag2 = flag2 << 16;

    /* 合并两个寄存器的值 */
    flag2 = (flag1 | flag2) & (uint32_t)0x00FFFFFF;
    } while(((flag2 & I2C_EVENT) != I2C_EVENT) && --timeout);

    /* 如非超时退出，则返回获取事件成功；否则返回获取事件失败 */
    if (timeout) {
        return READY;
    }
    else {
        BMP280_I2C->CTLR1 |= (uint16_t)0x0200;  //置位bit9:STOP位(在传输完当前数据后生停止位)
        return NoREADY;
    }
}

/**
  * @brief  将一字节数据或指令写入IIC数据寄存器,并等待数据移至移位寄存器(EV8,TxE=1)
  * @note   None
  * @param  data：待写入的数据或指令
  * @retval None
  */
static void BMP280_IIC_Send_Byte(uint8_t data)
{
    BMP280_I2C->DATAR = data;
    BMP280_CheckEvent(I2C_EVENT_MASTER_BYTE_TRANSMITTING);
}

/**
  * @brief  向BMP280写入测量参数
  * @note   None
  * @param  opt：操作指令
  *         dat:写入的命令或者数据
  * @retval IIC通信状态:1标识发送数据或指令成功，非1标识有IIC通信状态出错
  */
static uint8_t BMP280_Write_Command(uint8_t opt, uint8_t dat)
{
    /* 1.置位bit8:START位,发送起始信号,等待起始信号发出(EV5事件) */
    BMP280_I2C->CTLR1 |= (uint16_t)0x0100;
    if(BMP280_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT) == NoREADY) {
        return 3;
    }

    /* 2.向总线发送从机地址，等待从机ACK(ADDR位置位)，读取状态寄存器SR1和SR2将ADDR位清零(EV6事件) */
    BMP280_I2C->DATAR = BMP280_ADDR_W;  //I2C_Send7bitAddress(BMP280_I2C, BMP280_ADDR_W, I2C_Direction_Transmitter);
    if(BMP280_CheckEvent(I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED) == NoREADY) {
        return 2;
    }

    /* 3.发送寄存器地址和配置参数 */
    BMP280_IIC_Send_Byte(opt);
    BMP280_IIC_Send_Byte(dat);

    /* 4.置位bit9:STOP位(在传输完当前数据后生停止位) */
    BMP280_I2C->CTLR1 |= (uint16_t)0x0200;
    
    return 1;
}

/**
  * @brief  读取BMP280寄存器一字节数据
  * @note   None
  * @param  opt：操作指令
  * @retval BMP280发回的数据
  */
static uint8_t BMP280_Read_Byte(uint8_t opt)
{
    /* 1.置位bit8:START位,发送起始信号,等待起始信号发出(EV5事件) */
    BMP280_I2C->CTLR1 |= (uint16_t)0x0100;  //I2C_GenerateSTART(MPU6050_I2C, ENABLE);
    if(BMP280_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT) == NoREADY) {
        return 0;
    }

    /* 2.向总线发送从机地址,等待从机ACK(ADDR位置位),读取状态寄存器SR1和SR2将ADDR位清零(EV6事件) */
    BMP280_I2C->DATAR = BMP280_ADDR_W;      //I2C_Send7bitAddress(MPU6050_I2C, MPU6050_ADDR_W, I2C_Direction_Transmitter);
    if(BMP280_CheckEvent(I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED) == NoREADY) {
        return 0;
    }

    /* 3.发送MPU6050寄存器地址，等待数据发送完成(EV8_2:TxE位和BTF置位) */
    BMP280_I2C->DATAR = opt;
    if(BMP280_CheckEvent(I2C_EVENT_MASTER_BYTE_TRANSMITTED) == NoREADY) {
        return 0;
    }

    /* 4.置位bit8:START位,重新发送起始信号,等待起始信号发出(EV5事件);置位bit10:ACK位(在接收一个字节匹配地址或数据之后返回应答) */
    BMP280_I2C->CTLR1 |= (uint16_t)0x0500;
    if(BMP280_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT) == NoREADY) {
        return 0;
    }

    /* 5.向总线发送从机地址,等待从机ACK(ADDR位置位),读取状态寄存器SR1和SR2将ADDR位清零(EV6事件);复位ACK位,在接收当前数据之后NACK */
    BMP280_I2C->DATAR = BMP280_ADDR_R;      //I2C_Send7bitAddress(MPU6050_I2C, MPU6050_ADDR_R, I2C_Direction_Receiver);
    BMP280_I2C->CTLR1 &= (uint16_t)0xfbff;  //I2C_AcknowledgeConfig(MPU6050_I2C, DISABLE);
    if(BMP280_CheckEvent(I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED) == NoREADY) {
        return 0;
    }

    /* 6.置位bit9:STOP位(在传输完当前数据后生停止位) */
    BMP280_I2C->CTLR1 |= (uint16_t)0x0200;

    /* 7.等待EV7(RxNE:数据寄存器非空)，读取IIC数据寄存器的值 */
    if(BMP280_CheckEvent(I2C_EVENT_MASTER_BYTE_RECEIVED) == NoREADY) {
        return 0;
    }
    return BMP280_I2C->DATAR;
}

/**
  * @brief  读取BMP280校正系数和测量值
  * @note   本函数只适用于接收三字节及以上的数据，且寄存器地址需要连续
  * @param  bmp_reg：BMP280数据寄存器首地址
  *         bmp_data：存放读取数据的地址
  *         bmp_count：读取数量的个数(大于等于3)
  * @retval IIC通信状态:1标识成功接收到14字节数据,非1标识通信过程出错
  */
static uint8_t BMP280_Read_Stream(uint8_t bmp_reg, uint8_t *bmp_data, uint8_t bmp_count)
{
    /* 1.置位bit8:START位,发送起始信号,等待起始信号发出(EV5事件) */
    BMP280_I2C->CTLR1 |= (uint16_t)0x0100;
    if(BMP280_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT) == NoREADY) {
        return 9;
    }

    /* 2.向总线发送从机地址,等待从机ACK(ADDR位置位),读取状态寄存器SR1和SR2将ADDR位清零(EV6事件) */
    BMP280_I2C->DATAR = BMP280_ADDR_W;
    if(BMP280_CheckEvent(I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED) == NoREADY) {
        return 8;
    }

    /* 3.发送BMP280第一个数据寄存器地址，等待数据发送完成(EV8_2:TxE位和BTF置位) */
    BMP280_I2C->DATAR = bmp_reg;
    if(BMP280_CheckEvent(I2C_EVENT_MASTER_BYTE_TRANSMITTED) == NoREADY) {
        return 7;
    }

    /* 4.置位bit8:START位,重新发送起始信号,等待起始信号发出(EV5事件);置位bit10:ACK位(在接收一个字节匹配地址或数据之后返回应答) */
    BMP280_I2C->CTLR1 |= (uint16_t)0x0500;
    if(BMP280_CheckEvent(I2C_EVENT_MASTER_MODE_SELECT) == NoREADY) {
        return 6;
    }

    /* 5.向总线发送从机地址,等待从机ACK(ADDR位置位),读取状态寄存器SR1和SR2将ADDR位清零(EV6事件) */
    BMP280_I2C->DATAR = BMP280_ADDR_R;
    if(BMP280_CheckEvent(I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED) == NoREADY) {
        return 5;
    }

    /* 6.读取BMP280发回的前(N-2)个字节数据(EV7:RxNE(数据寄存器非空)) */
    while(bmp_count)
    {
        if(BMP280_CheckEvent(I2C_EVENT_MASTER_BYTE_RECEIVED) == NoREADY) {
            return 4;
        }
        *bmp_data = BMP280_I2C->DATAR;      //读取接收到的测量数据
        bmp_data++;                         //指向下一个数据存放的地址
        bmp_count--;                        //计数值减1
        if(bmp_count == 2)                  //只读取前N-2个
            break;
    }

    /* 7.读取BMP280发送的第(N-1)字节数据(EV7:RxNE(数据寄存器非空);复位bit10:ACK位,接收当前字节后发送NACK */
    if(BMP280_CheckEvent(I2C_EVENT_MASTER_BYTE_RECEIVED) == NoREADY) {
        return 3;
    }
    BMP280_I2C->CTLR1 &= (uint16_t)0xfbff;  //复位ACK位（在接收一个字节（匹配地址或数据）之后NACK）
    *bmp_data = BMP280_I2C->DATAR;          //接收第(N-1)字节数据

    /* 8.置位bit9:STOP位(在传输完当前数据后生停止位) */
    BMP280_I2C->CTLR1 |= (uint16_t)0x0200;

    /* 9.等待EV7(RxNE:数据寄存器非空),读取第N字节数据 */
    if(BMP280_CheckEvent(I2C_EVENT_MASTER_BYTE_RECEIVED) == NoREADY) {
        return 2;
    }
    bmp_data++;                             //指向下一个数据存放的地址
    *bmp_data = BMP280_I2C->DATAR;          //接收第N字节数据
    return 1;                               //标识接收数据成功
}

/**
  * @brief  将BMP280补偿系数合并成16bit数据
  * @note   BMP280_Parameters为补偿参数结构体变量，定义在第3行
  * @param  raw_value：存放读取出的BMP280原始补偿系数的地址
  * @retval None
  */
static void BMP280_Merge_Raw_Parameters(uint8_t *raw_value)
{
    BMP280_Parameters.T1 = raw_value[1];
    BMP280_Parameters.T1 <<= 8;
    BMP280_Parameters.T1 |= raw_value[0];

    BMP280_Parameters.T2 = raw_value[3];
    BMP280_Parameters.T2 <<= 8;
    BMP280_Parameters.T2 |= raw_value[2];

    BMP280_Parameters.T3 = raw_value[5];
    BMP280_Parameters.T3 <<= 8;
    BMP280_Parameters.T3 |= raw_value[4];

    BMP280_Parameters.P1 = raw_value[7];
    BMP280_Parameters.P1 <<= 8;
    BMP280_Parameters.P1 |= raw_value[6];

    BMP280_Parameters.P2 = raw_value[9];
    BMP280_Parameters.P2 <<= 8;
    BMP280_Parameters.P2 |= raw_value[8];

    BMP280_Parameters.P3 = raw_value[11];
    BMP280_Parameters.P3 <<= 8;
    BMP280_Parameters.P3 |= raw_value[10];

    BMP280_Parameters.P4 = raw_value[13];
    BMP280_Parameters.P4 <<= 8;
    BMP280_Parameters.P4 |= raw_value[12];

    BMP280_Parameters.P5 = raw_value[15];
    BMP280_Parameters.P5 <<= 8;
    BMP280_Parameters.P5 |= raw_value[14];

    BMP280_Parameters.P6 = raw_value[17];
    BMP280_Parameters.P6 <<= 8;
    BMP280_Parameters.P6 |= raw_value[16];

    BMP280_Parameters.P7 = raw_value[19];
    BMP280_Parameters.P7 <<= 8;
    BMP280_Parameters.P7 |= raw_value[18];

    BMP280_Parameters.P8 = raw_value[21];
    BMP280_Parameters.P8 <<= 8;
    BMP280_Parameters.P8 |= raw_value[20];

    BMP280_Parameters.P9 = raw_value[23];
    BMP280_Parameters.P9 <<= 8;
    BMP280_Parameters.P9 |= raw_value[22];
}

/**
  * @brief  读取BMP280补偿系数，设置工作模式
  * @note   CH32V103R8T6平台硬件I2C SCL=400KHz,高低电平需为2:1
  * @param  None
  * @retval 1：读出补偿系数，并完成初始化配置；0：BMP280状态忙，初始化失败。
  */
uint8_t BMP280_Init(void)
{
    uint8_t status = 0x09;                                                          //状态寄存器只有bit3和bit0有效
    uint8_t BMP280_Trimming_Raw_Parameters[24];                                     //存放测量补偿系数的数组
    status = BMP280_Read_Byte(BMP280_STATUS);                                       //读取状态寄存器值
    if(!(status & BMP280_IM_UPDATE_OK))                                             //如果补偿系数已就绪，读取补偿系数，并初始化工作模式
    {
        BMP280_Read_Stream(BMP280_DIG_T1_LSB, BMP280_Trimming_Raw_Parameters, 24);  //读取补偿系数
        BMP280_Write_Command(BMP280_RESET, 0xB6);                                   //发送复位BMP280指令
        BMP280_Merge_Raw_Parameters(BMP280_Trimming_Raw_Parameters);                //合并补偿系数为16bit数据
        BMP280_Write_Command(BMP280_CTRL_MEAS, 0x5F);   //配置x2温度、x16气压采样模式,工作在Normal模式
        BMP280_Write_Command(BMP280_CONFIG, 0xCC);      //配置转换间隔时间2s和滤波系数x8
        return 1;
    }
    else {
        return 0;
    }
}

/**
  * @brief  读取BMP280设备ID
  * @note   正确返回值是0x58，可以以此判断设备是否连接正常
  * @param  None
  * @retval BMP280设备ID
  */
uint8_t BMP280_GetID(void)
{
    return BMP280_Read_Byte(BMP280_CHIP_ID);
}

/**
  * @brief  将接收到的6字节原始数据分别合并成20bit数据
  * @note   None
  * @param  *measured_value：合并后的20bit数据
  *         *value：从BMP280接收到的原始数据
  * @retval None
  */
static void BMP280_Merge_Measured_value(int32_t *measured_value, uint8_t *value)
{
    measured_value[0] |= (int32_t)value[0];
    measured_value[0] <<= 8;
    measured_value[0] |= (int32_t)value[1];
    measured_value[0] <<= 8;
    measured_value[0] |= (int32_t)value[2];
    measured_value[0] >>= 4;                //气压数据

    measured_value[1] |= (int32_t)value[3];
    measured_value[1] <<= 8;
    measured_value[1] |= (int32_t)value[4];
    measured_value[1] <<= 8;
    measured_value[1] |= (int32_t)value[5];
    measured_value[1] >>= 4;                //温度数据
}

/**
  * @brief  将BMP280测量的20bit测量值换算成实际值
  * @note   None
  * @param  bmp_value：气压和温度计算结果地址
  *         measured_data：气压和温度20bit原始测量值地址
  * @retval None
  */
static void BMP280_Calc_Measured_Value(int32_t *bmp_value, int32_t *measured_data)
{
    float Temp1 = 0, Temp2 = 0, Temp3 = 0;

    /*换算实际温度*/
    Temp1 = ((float)measured_data[1] / 16384.0f - (float)BMP280_Parameters.T1 / 1024.0f) * (float)BMP280_Parameters.T2;
    Temp2 = ((float)measured_data[1] / 131072.0f - (float)BMP280_Parameters.T1 / 8192.0f) * ((float)measured_data[1] / 131072.0f - (float)BMP280_Parameters.T1 / 8192.0f) * (float)BMP280_Parameters.T3;
    Temp3 = Temp1 + Temp2;
    bmp_value[1] = Temp3 / 51.20f;   //温度值放大100倍

    /*换算实际气压*/
    Temp1 = 0; Temp2 = 0;
    Temp1 = Temp3 / 2.0f - 64000.0f;
    Temp2 = Temp1 * Temp1 * (float)BMP280_Parameters.P6 / 32768.0f;
    Temp2 = Temp2 + Temp1 * BMP280_Parameters.P5 * 2.0f;
    Temp2 = (float)Temp2 / 4.0f + (float)BMP280_Parameters.P4 * 65536.0f;
    Temp1 = ((float)BMP280_Parameters.P3 * Temp1 * Temp1 / 524288.0f + (float)BMP280_Parameters.P2 * Temp1) / 524288.0f;
    Temp1 = (1.0f + (float)Temp1 / 32768.0f) * BMP280_Parameters.P1;
    Temp3 = 0;
    Temp3 = 1048576.0f - measured_data[0];
    Temp3 = (Temp3 - (float)Temp2 / 4096.0f) * 6250.0f / Temp1;
    Temp1 = (float)BMP280_Parameters.P9 * Temp3 * Temp3 / 2147483648.0f;
    Temp2 = Temp3 * (float)BMP280_Parameters.P8 / 32768.0f;
    Temp3 = Temp3 + (float)(Temp1 + Temp2 + BMP280_Parameters.P7) / 16.0f;
    bmp_value[0] = Temp3;
}

/**
  * @brief  获取BMP280测量的气压和温度值
  * @note   温度值放大100倍(保留两位小数)
  * @param  bmp_value:存放气压和温度测量值的地址
  * @retval 1：读出测量值；0：BMP280正在转换数据，读取测量值失败
  */
uint8_t BMP280_Measured_Value(int32_t *bmp_value)
{
    uint8_t status = 0x09;                                      //状态寄存器只有bit3和bit0有效
    bmp_value[0] = 0;                                           //清空已有值
    bmp_value[1] = 0;                                           //清空已有值
    uint8_t bmp_data[6];                                        //缓存读取的原始测量数据
    int32_t measured_value[2] = {0, 0};                         //缓存合并的20bit测量数据
    status = BMP280_Read_Byte(BMP280_STATUS);                   //读取状态寄存器值
    if(!(status & BMP280_MEASURING_OK))                         //如果测量数据已就绪，则读出，并做处理
    {
        BMP280_Read_Stream(BMP280_PRESS_MSB, bmp_data, 6);      //读取测量的温度和气压测量值(6字节)
        BMP280_Merge_Measured_value(measured_value, bmp_data);  //合并6字节测量值为两个20bit数据
        BMP280_Calc_Measured_Value(bmp_value, measured_value);  //将合并的测量值换算成实际值
        return 1;
    }
    else {
        return 0;
    }
}

/**
  * @brief  BMP280测量的温度数据转为ASCII码
  * @note   None
  * @param  raw_data:BMP280测量的温度数据
  *         Temp_str:本次转换的显示数据存储地址
  * @retval None
  */
uint8_t BMP280_T_Raw_Data_Transform(int32_t *raw_data, uint8_t *Temp_str)
{
    uint8_t cnt = 0, temp_data;

    if(*raw_data & (int32_t)0x80000000) //判断温度是否为负(BMP280计算的结果是有符号数，且已经放大一百倍)
    {
        *raw_data = -(*raw_data);       //将负数转换为相反数

        /*将'-'ASCII码写入显示缓存数组*/
        Temp_str[0] = '-';

        /*将计算值按低位到高位分离并存至缓存数组*/
        do {
            cnt++;
            Temp_str[cnt] = *raw_data % 10;
            *raw_data /= 10;
        } while(*raw_data);

        /*根据测量值选择对应的处理方案*/
        switch(cnt) {
            case 4:                             //温度为-ab.cd(交换前为'-'dcba)
            {
                temp_data = Temp_str[1] + 48;   //缓存d,并换算成对应ASCII码'd'
                Temp_str[1] = Temp_str[4] + 48; //将a换算成'a'并存至第一个整数位('-''a'cba)
                Temp_str[5] = temp_data;        //将'd'存至小数点后第二位('-''a'cba'd')
                temp_data = Temp_str[2] + 48;   //缓存c,并换算成对应ASCII码'c'
                Temp_str[2] = Temp_str[3] + 48; //将b换算成'b'并存至第二个整数位('-''a''b'ba'd')
                Temp_str[4] = temp_data;        //将'c'存至小数点后第一位('-''a''b'b'c''d')
                Temp_str[3] = '.';              //将小数点置于第二位整数后('-''a''b''.''c''d')
                Temp_str[6] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[7] = 0xE6;
                cnt = 6;
                break;
            }
            case 3:                             //温度为-a.bc(交换前为'-'cba)
            {
                temp_data = Temp_str[1] + 48;   //缓存c,并换算成对应ASCII码'c'
                Temp_str[1] = Temp_str[3] + 48; //将a换算成'a'并存至第一个整数位('-''a'ba)
                Temp_str[3] = Temp_str[2] + 48; //将b换算成'b'并存至小数点后第一位('-''a'b'b')
                Temp_str[4] = temp_data;        //将'c'存至小数点后第二位('-''a'b'b''c')
                Temp_str[2] = '.';              //将小数点置于整数后('-''a''.''b''c')
                Temp_str[5] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[6] = 0xE6;
                cnt = 5;
                break;
            }
            case 2:                             //温度为-0.ab(交换前为'-'ba)
            {
                Temp_str[4] = Temp_str[1] + 48; //将b换算成'b'并存至小数点后第二位('-'ba 'b')
                Temp_str[3] = Temp_str[2] + 48; //将a换算成'a'并存至小数点后第一位('-'ba'a''b')
                Temp_str[1] = '0';              //补'0'('-''0'a'a''b')
                Temp_str[2] = '.';              //将小数点置于'0'后('-''0''.''a''b')
                Temp_str[5] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[6] = 0xE6;
                cnt = 5;
                break;
            }
            case 1:                             //温度为-0.0a(交换前为'-'a)
            {
                Temp_str[4] = Temp_str[1] + 48; //将a换算成'a'并存至小数点后第二位('-'a  'a')
                Temp_str[1] = '0';              //补'0'('-''0'  'a')
                Temp_str[2] = '.';              //将小数点置于'0'后('-''0''.' 'a')
                Temp_str[3] = '0';              //小数点后补'0'(('-''0''.''0''a') )
                Temp_str[5] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[6] = 0xE6;
                cnt = 5;
                break;
            }
            default :                           //测量值无效
            {
                Temp_str[0] = 'N';
                Temp_str[1] = 'U';
                Temp_str[2] = 'L';
                Temp_str[3] = 'L';
                cnt = 0;
                break;
            }
        }
    }
    else                                        //测量温度为正的处理方式
    {
        /*将计算值按位(从低位位到高位)分离并存至缓存数组*/
        do {
            Temp_str[cnt] = *raw_data % 10;
            *raw_data /= 10;
            cnt++;
        } while(*raw_data);

        /*根据测量值选择对应的处理方案*/
        switch(cnt) {
            case 5:                             //温度为abc.de(交换前为edcba)
            {
                temp_data = Temp_str[0] + 48;   //缓存e,并换算成对应ASCII码'e'
                Temp_str[0] = Temp_str[4] + 48; //将a换算成'a'并存至第一个整数位('a'dcba)
                Temp_str[5] = temp_data;        //将'e'存至小数点后第二位('a'dcba'e')
                temp_data = Temp_str[1] + 48;   //缓存d,并换算成对应ASCII码'd'
                Temp_str[1] = Temp_str[3] + 48; //将b换算成'b'并存至第二个整数位('a''b'cba'e')
                Temp_str[4] = temp_data;        //将'd'存至小数点后第一位('a''b'cb'd''e')
                Temp_str[2] = Temp_str[2] + 48; //将c换算成'c'并存至第三个整数位('a''b''c'b'd''e')
                Temp_str[3] = '.';              //将小数点置于第二位整数后('a''b''c''.''d''e')
                Temp_str[6] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[7] = 0xE6;
                cnt = 6;
                break;
            }
            case 4:                             //温度为ab.cd(交换前为dcba)
            {
                temp_data = Temp_str[0] + 48;   //缓存d,并换算成对应ASCII码'd'
                Temp_str[0] = Temp_str[3] + 48; //将a换算成'a'并存至第一个整数位('a'cba)
                Temp_str[4] = temp_data;        //将'd'存至小数点后第二位('a'cba'd')
                temp_data = Temp_str[1] + 48;   //缓存c,并换算成对应ASCII码'c'
                Temp_str[1] = Temp_str[2] + 48; //将b换算成'b'并存至第二个整数位('a''b'ba'd')
                Temp_str[3] = temp_data;        //将'c'存至小数点后第一位('a''b'b'c''d')
                Temp_str[2] = '.';              //将小数点置于第二位整数后('a''b''.''c''d')
                Temp_str[5] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[6] = 0xE6;
                cnt = 5;
                break;
            }
            case 3:                             //温度为a.bc(交换前为cba)
            {
                temp_data = Temp_str[0] + 48;   //缓存c,并换算成对应ASCII码'c'
                Temp_str[0] = Temp_str[2] + 48; //将a换算成'a'并存至第一个整数位('a'ba)
                Temp_str[2] = Temp_str[1] + 48; //将b换算成'b'并存至小数点后第一位('a'b'b')
                Temp_str[3] = temp_data;        //将'c'存至小数点后第二位('a'b'b''c')
                Temp_str[1] = '.';              //将小数点置于整数后('a''.''b''c')
                Temp_str[4] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[5] = 0xE6;
                cnt = 4;
                break;
            }
            case 2:                             //温度为0.ab(交换前为ba)
            {
                Temp_str[3] = Temp_str[0] + 48; //将b换算成'b'并存至小数点后第二位(ba 'b')
                Temp_str[2] = Temp_str[1] + 48; //将a换算成'a'并存至小数点后第一位(ba'a''b')
                Temp_str[0] = '0';              //补'0'('0'a'a''b')
                Temp_str[1] = '.';              //将小数点置于'0'后('0''.''a''b')
                Temp_str[4] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[5] = 0xE6;
                cnt = 4;
                break;
            }
            case 1:                             //温度为0.0a(交换前为a)
            {
                Temp_str[3] = Temp_str[0] + 48; //将a换算成'a'并存至小数点后第二位(a  'a')
                Temp_str[0] = '0';              //补'0' ('0'  'a')
                Temp_str[1] = '.';              //将小数点置于'0'后('0''.' 'a')
                Temp_str[2] = '0';              //小数点后补'0'('0''.''0''a')
                Temp_str[4] = 0xA1;             //添加℃符号GBK编码值
                Temp_str[5] = 0xE6;
                cnt = 4;
                break;
            }
            default :                           //无效值处理
            {
                Temp_str[0] = 'N';
                Temp_str[1] = 'U';
                Temp_str[2] = 'L';
                Temp_str[3] = 'L';
                cnt = 0;
                break;
            }
        }
    }
    return cnt;                                 //返回气压值位数
}

/**
  * @brief  BMP280测量的气压数据转为ASCII码
  * @note   以1Pa精度(测量计算值)形式显示
  * @param  raw_data:BMP280测量的气压数据(精度1Pa)
  *         Temp_str:本次转换的显示数据存储地址
  * @retval None
  */
uint8_t BMP280_P_Raw_Data_Transform(int32_t *raw_data, uint8_t *Temp_str)
{
    uint8_t cnt = 0, temp_data;

    /*将计算值按位(从低位位到高位)分离并存至缓存数组*/
    do {
        Temp_str[cnt] = *raw_data % 10;
        *raw_data /= 10;
        cnt++;
    } while(*raw_data);

    /*根据测量值选择对应的处理方案*/
    switch(cnt) {
        case 6:                             //气压为abcdef帕斯卡(Pa)(交换前为fedcba)
        {
            temp_data = Temp_str[0] + 48;   //缓存f,并换算成对应ASCII码'f'
            Temp_str[0] = Temp_str[5] + 48; //将a换算成'a'并存至第一个整数位('a'edcba)
            Temp_str[5] = temp_data;        //将'f'存至第六个整数位('a'edcb'f')
            temp_data = Temp_str[1] + 48;   //缓存e,并换算成对应ASCII码'e'
            Temp_str[1] = Temp_str[4] + 48; //将b换算成'b'并存至第二个整数位('a''b'dcb'f')
            Temp_str[4] = temp_data;        //将'e'存至第五个整数位('a''b'dc'e''f')
            temp_data = Temp_str[2] + 48;   //缓存d,并换算成对应ASCII码'd'
            Temp_str[2] = Temp_str[3] + 48; //将c换算成'c'并存至第三个整数位('a''b''c'c'e''f')
            Temp_str[3] = temp_data;        //将'd'存至第四个整数位('a''b''c''d''e''f')
            Temp_str[6] = 'P';
            Temp_str[7] = 'a';
            break;
        }
        case 5:                             //气压为abcde帕斯卡(Pa)(交换前为edcba)
        {
            temp_data = Temp_str[0] + 48;   //缓存e,并换算成对应ASCII码'e'
            Temp_str[0] = Temp_str[4] + 48; //将a换算成'a'并存至第一个整数位('a'dcba)
            Temp_str[4] = temp_data;        //将'e'存至第五个整数位('a'dcb'e')
            temp_data = Temp_str[1] + 48;   //缓存d,并换算成对应ASCII码'd'
            Temp_str[1] = Temp_str[3] + 48; //将b换算成'b'并存至第二个整数位('a''b'cb'e')
            Temp_str[3] = temp_data;        //将'd'存至第四个整数位('a''b'c'd''e')
            Temp_str[2] = Temp_str[2] + 48; //将c换算成'c'并存至第三个整数位('a''b''c''d''e')
            Temp_str[5] = 'P';
            Temp_str[6] = 'a';
            break;
        }
        case 4:                             //气压为abcd帕斯卡(Pa)(交换前为dcba)
        {
            temp_data = Temp_str[0] + 48;   //缓存d,并换算成对应ASCII码'd'
            Temp_str[0] = Temp_str[3] + 48; //将a换算成'a'并存至第一个整数位('a'cba)
            Temp_str[3] = temp_data;        //将'd'存至第四个整数位('a'cb'd')
            temp_data = Temp_str[1] + 48;   //缓存c,并换算成对应ASCII码'c'
            Temp_str[1] = Temp_str[2] + 48; //将b换算成'b'并存至第二个整数位('a''b'b'd')
            Temp_str[2] = temp_data;        //将'c'存至第三个整数位('a''b''c''d')
            Temp_str[4] = 'P';
            Temp_str[5] = 'a';
            break;
        }
        case 3:                             //气压为abc帕斯卡(Pa)(交换前为cba)
        {
            temp_data = Temp_str[0] + 48;   //缓存c,并换算成对应ASCII码'c'
            Temp_str[0] = Temp_str[2] + 48; //将a换算成'a'并存至第一个整数位('a'ba)
            Temp_str[2] = temp_data;        //将'c'存至第三个整数位('a'b'c')
            Temp_str[1] = Temp_str[1] + 48; //将b换算成'b'并存至第二个整数位('a''b''c')
            Temp_str[3] = 'P';
            Temp_str[4] = 'a';
            break;
        }
        case 2:                             //气压为ab帕斯卡(Pa)(交换前为ba)
        {
            temp_data = Temp_str[0] + 48;   //缓存b,并换算成对应ASCII码'b'
            Temp_str[0] = Temp_str[1] + 48; //将a换算成'a'并存至第一个整数位('a'a)
            Temp_str[1] = temp_data;        //将'b'存至第二个整数位('a''b')
            Temp_str[2] = 'P';
            Temp_str[3] = 'a';
            break;
        }
        case 1:                             //气压为a帕斯卡(Pa)(交换前为a)
        {
            Temp_str[0] = Temp_str[0] + 48; //将a换算成'a'('a')
            Temp_str[1] = 'P';
            Temp_str[2] = 'a';
            break;
        }
        default :                           //读取值无效
        {
            Temp_str[0] = 'N';
            Temp_str[1] = 'U';
            Temp_str[2] = 'L';
            Temp_str[3] = 'L';
            cnt = 0;
            break;
        }
    }
    return cnt;                             //返回气压值位数
}
