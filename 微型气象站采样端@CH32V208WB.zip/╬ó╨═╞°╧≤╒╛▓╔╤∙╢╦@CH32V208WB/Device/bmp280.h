#ifndef __BMP280_H
#define __BMP280_H

#include "ch32v20x.h"

#define BMP280_I2C          I2C1    //BMP280挂载的IIC总线
#define BMP280_ADDR_W       0xEC    //写操作(SDO下拉)
#define BMP280_ADDR_R       0xED    //读操作(SDO下拉)

/*复位BMP280指令 */
#define BMP280_RESET_CMD    0xB6    //向寄存器地址"0xE0"写入"0xB6"复位BMP280
#define BMP280_MEASURING_OK 0x08    //测量转换结果已经存入数据寄存器，完成时此位清0
#define BMP280_IM_UPDATE_OK 0x01    //补偿系数已经存入数据寄存器，完成时此位清0

/*BMP280数据寄存器地址 */
#define BMP280_CHIP_ID      0xD0    //设备ID寄存器地址,固定值"0x58",上电复位后即可读取
#define BMP280_RESET        0xE0    //复位寄存器地址,仅写入"0xB6"有效；读取值为0x00
#define BMP280_STATUS       0xF3    //状态寄存器地址,仅使用bit3[清0：测量数据就绪]和bit0[清0：补偿系数就绪]
#define BMP280_CTRL_MEAS    0xF4    //设置BMP280温度bit[7:5]、气压bit[4:2]采集精度和工作模式bit[1:0]寄存器地址
#define BMP280_CONFIG       0xF5    //设置"Normal"模式转换间隔时间bit[7:5]、滤波系数bit[4:2]和SPI模式bit0
#define BMP280_PRESS_MSB    0xF7    //采样的压力原始数据bit[19:12]
#define BMP280_PRESS_LSB    0xF8    //采样的压力原始数据bit[11:4]
#define BMP280_PRESS_XLSB   0xF9    //采样的压力原始数据bit[3:0](bit 7, 6, 5, 4)
#define BMP280_TEMP_MSB     0xFA    //采样的温度原始数据bit[19:12]
#define BMP280_TEMP_LSB     0xFB    //采样的温度原始数据bit[11:4]
#define BMP280_TEMPE_XLSB   0xFC    //采样的温度原始数据bit[3:0](bit 7, 6, 5, 4)

/*BMP280补偿系数寄存器地址 (共24个)*/
#define BMP280_DIG_T1_LSB   0x88
#define BMP280_DIG_T1_MSB   0x89
#define BMP280_DIG_T2_LSB   0x8A
#define BMP280_DIG_T2_MSB   0x8B
#define BMP280_DIG_T3_LSB   0x8C
#define BMP280_DIG_T3_MSB   0x8D
#define BMP280_DIG_P1_LSB   0x8E
#define BMP280_DIG_P1_MSB   0x8F
#define BMP280_DIG_P2_LSB   0x90
#define BMP280_DIG_P2_MSB   0x91
#define BMP280_DIG_P3_LSB   0x92
#define BMP280_DIG_P3_MSB   0x93
#define BMP280_DIG_P4_LSB   0x94
#define BMP280_DIG_P4_MSB   0x95
#define BMP280_DIG_P5_LSB   0x96
#define BMP280_DIG_P5_MSB   0x97
#define BMP280_DIG_P6_LSB   0x98
#define BMP280_DIG_P6_MSB   0x99
#define BMP280_DIG_P7_LSB   0x9A
#define BMP280_DIG_P7_MSB   0x9B
#define BMP280_DIG_P8_LSB   0x9C
#define BMP280_DIG_P8_MSB   0x9D
#define BMP280_DIG_P9_LSB   0x9E
#define BMP280_DIG_P9_MSB   0x9F

/*定义计算气压温度结构体变量BMP280*/
typedef struct
{
    uint16_t T1;
    int16_t T2;
    int16_t T3;
    uint16_t P1;
    int16_t P2;
    int16_t P3;
    int16_t P4;
    int16_t P5;
    int16_t P6;
    int16_t P7;
    int16_t P8;
    int16_t P9;
} BMP280_Trimming_Parameters_TypeDef;

uint8_t BMP280_Init(void);
uint8_t BMP280_GetID(void);
uint8_t BMP280_Measured_Value(int32_t *bmp_value);

uint8_t BMP280_T_Raw_Data_Transform(int32_t *raw_data, uint8_t *Temp_str);
uint8_t BMP280_P_Raw_Data_Transform(int32_t *raw_data, uint8_t *Temp_str);

#endif /* __BMP280_H */
