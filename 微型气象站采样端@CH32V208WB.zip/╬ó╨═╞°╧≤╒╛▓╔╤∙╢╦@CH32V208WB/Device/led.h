#ifndef __LED_H
#define __LED_H

#include "ch32v20x.h"

#define LED1_CLK     RCC_APB2Periph_GPIOD
#define LED1_Port    GPIOD
#define LED1_Pin     GPIO_Pin_4

#define LED1_TOGGLE  LED1_Port->OUTDR ^= LED1_Pin
#define LED1_ON      LED1_Port->BCR = LED1_Pin
#define LED1_OFF     LED1_Port->BSHR = LED1_Pin

void LED_Init(void);

#endif /* __LED_H */
