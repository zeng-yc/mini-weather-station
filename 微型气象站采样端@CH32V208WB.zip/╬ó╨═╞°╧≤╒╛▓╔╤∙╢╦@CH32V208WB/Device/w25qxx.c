#include "w25qxx.h"

/**
  * @brief  初始化Flash片选引脚
  * @note   None
  * @param  None
  * @retval None
  */
void W25Qxx_CS_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    RCC_APB2PeriphClockCmd(W25Qx_CS_CLK, ENABLE);
    
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;   //推挽输出模式
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;  //10MHz
    GPIO_InitStruct.GPIO_Pin = W25Qx_CS_Pin;        //初始化的引脚号
    GPIO_Init(W25Qx_CS_Port, &GPIO_InitStruct);     //片选引脚配置为推挽输出
    
    W25Qx_CS_1;                                     //输出高电平，拉高W25Qx片选引脚
}

/**
  * @brief  SPI接收发送单个字节功能函数
  * @note   基础SPI通信程序程序，直接操作寄存器提升执行效率
  * @param  data:需要发送的数据
  * @retval 接收到的数据
  */
static uint8_t W25Qxx_SPI_TR_Byte(uint8_t data)
{
    uint16_t cnt = 20000;                                   //超时计数变量
    W25Qx_SPI->DATAR = data;                                //向发送缓冲区写入数据
    while(!(W25Qx_SPI->STATR & SPI_I2S_FLAG_TXE) && --cnt); //等待TXE发送缓冲区为空
    cnt = 20000;                                            //复位计数变量
    while((W25Qx_SPI->STATR & SPI_I2S_FLAG_BSY) && --cnt);  //等待BSY位复位(本次通信完成)
    return W25Qx_SPI->DATAR;                                //读取接收到的数据
}

/**
  * @brief  SPI Flash写使能
  * @note   None
  * @param  None
  * @retval None
  */
static void W25Qxx_Write_Enable(void)
{
    W25Qx_CS_0;                             //片选Flash
    W25Qxx_SPI_TR_Byte(W25Qx_WRITE_ENABLE); //发送写使能命令
    W25Qx_CS_1;                             //取消片选Flash
}

/**
  * @brief  等待Flash写入数据完成
  * @note   None
  * @param  None
  * @retval None
  */
static void W25Qxx_Wait_Write_Idle(void)
{
    uint8_t sr = 0;
    W25Qx_CS_0;                         //片选Flash
    W25Qxx_SPI_TR_Byte(W25Qx_READ_SR1); //读取状态寄存器1
    do {
        sr = W25Qxx_SPI_TR_Byte(W25Qx_Dummy_Byte);   //获取状态寄存器1的返回值
    }while(sr & 0x01);                  //等待状态寄存器1 bit0:BUSY位复位
    W25Qx_CS_1;                         //取消片选Flash
}

/**
  * @brief  擦除整片Flash的数据
  * @note   None
  * @param  None
  * @retval None
  */
void W25Qxx_Chip_Erase(void)
{
    W25Qxx_Write_Enable();                  //写使能
    W25Qxx_Wait_Write_Idle();               //等待Flash空闲
    W25Qx_CS_0;                             //片选Flash
    W25Qxx_SPI_TR_Byte(W25Qx_CHIP_ERASE);   //发送整片擦除命令
    W25Qx_CS_1;                             //取消片选Flash
    W25Qxx_Wait_Write_Idle();               //等待擦除完成
}

/**
  * @brief  擦除Flash指定扇区的数据
  * @note   None
  * @param  SectorAddr：扇区起始地址
  * @retval None
  */
void W25Qxx_Sector_Erase(uint32_t SectorAddr)
{
    W25Qxx_Write_Enable();                              //写使能
    W25Qxx_Wait_Write_Idle();                           //等待Flash空闲
    W25Qx_CS_0;                                         //片选Flash
    W25Qxx_SPI_TR_Byte(W25Qx_SECTOR_ERASE);             //发送扇区擦除命令
    W25Qxx_SPI_TR_Byte((SectorAddr & 0xff0000) >> 16);  //发送扇区地址bit23:16(Block编号)
    W25Qxx_SPI_TR_Byte((SectorAddr & 0xff00) >> 8);     //发送扇区地址bit15:8(bit15:12扇区编号)
    W25Qxx_SPI_TR_Byte(SectorAddr & 0xff);              //发送扇区地址bit7:0
    W25Qx_CS_1;                                         //取消片选Flash
    W25Qxx_Wait_Write_Idle();                           //等待擦除完成
}

/**
  * @brief  读取flash中的数据
  * @note   发送命令0x03读取Flash中的数据
  * @param  Addr：起始地址
  *         *buf：读取到的数据
  *         cnt：读取的数据个数
  * @retval None
  */
void W25Qxx_Read_Data(uint32_t Addr, uint8_t *buf, uint32_t cnt)
{
    W25Qx_CS_0;                                     //片选Flash
    W25Qxx_SPI_TR_Byte(W25Qx_READ_DATA);            //发送读取数据命令
    W25Qxx_SPI_TR_Byte((Addr & 0xff0000) >> 16);    //发送扇区地址bit23:16(Block编号)
    W25Qxx_SPI_TR_Byte((Addr & 0xff00) >> 8);       //发送扇区地址bit15:8(bit15:12扇区编号)
    W25Qxx_SPI_TR_Byte(Addr & 0xff);                //发送扇区地址bit7:0
    while(cnt--)
    {
        *buf = W25Qxx_SPI_TR_Byte(W25Qx_Dummy_Byte);//接收读取到的数据
        buf++;                                      //接收数据地址指向下一个
    }    
    W25Qx_CS_1;                                     //取消片选Flash
}

/**
  * @brief  读取flash中的数据
  * @note   发送命令0x03读取Flash中的数据
  * @param  Addr：起始地址
  *         *buf：读取到的数据
  *         cnt：读取的数据个数
  * @retval None
  */
void W25Qxx_DMA_Read_Data(uint32_t Addr, uint8_t *buf, uint16_t cnt)
{
    uint16_t num = 60000;                           //超时计数变量
    uint8_t tx_temp[cnt + 4];                       //定义缓冲数组
    tx_temp[0] = W25Qx_READ_DATA;                   //读数据命令
    tx_temp[1] = (Addr & 0xff0000) >> 16;           //扇区地址bit23:16(Block编号)
    tx_temp[2] = (Addr & 0xff00) >> 8;              //扇区地址bit15:8(bit15:12扇区编号)
    tx_temp[3] = Addr & 0xff;                       //扇区地址bit7:0
    W25Qx_SPI_DMA_TX->MADDR = (uint32_t)tx_temp;    //设置SPIx_DMA_TX存储器地址(地址未更改不用重新配置)
    W25Qx_SPI_DMA_RX->MADDR = (uint32_t)buf;        //设置SPIx_DMA_RX存储器地址(地址未更改不用重新配置)
    W25Qx_SPI_DMA_RX->CFGR |= (uint16_t)0x0080;     //使能SPIx_DMA_RX接收存储器地址递增
    W25Qx_SPI_DMA_TX->CNTR = cnt + 4;               //设置SPIx_DMA_TX传输数据个数
    W25Qx_SPI_DMA_RX->CNTR = cnt + 4;               //设置SPIx_DMA_RX接收数据个数
    W25Qx_CS_0;                                     //片选Flash
    W25Qx_SPI_DMA_TX->CFGR |= (uint16_t)0x0001;     //使能SPIx_DMA_TX开始发送数据
    W25Qx_SPI_DMA_RX->CFGR |= (uint16_t)0x0001;     //使能SPIx_DMA_RX开始接收数据
    while(!(W25Qx_SPI->STATR & SPI_I2S_FLAG_TXE) && --num); //等待SPI_SR状态寄存器TXE=1(写入SPI_DR的最后一个数据开始传输)
    num = 60000;                                    //重置计数值
    while((W25Qx_SPI->STATR & SPI_I2S_FLAG_BSY) && --num);  //等待SPI_SR状态寄存器BSY=0(SPI通讯结束)
    W25Qx_CS_1;                                     //取消片选Flash
}

/**
  * @brief  向flash中写入数据
  * @note   发送命令PAGE_PROGRAM(0x02)向Flash写入数据
  * @param  Addr：起始地址
  *         *buf：需要写入的数据
  *         cnt：写入的数据个数
  * @retval None
  */
void W25Qxx_Page_Write(uint32_t Addr, uint8_t *buf, uint16_t cnt)
{
    W25Qxx_Write_Enable();                          //写使能
    W25Qx_CS_0;                                     //片选Flash
    W25Qxx_SPI_TR_Byte(W25Qx_PAGE_PROGRAM);         //发送页写入命令
    W25Qxx_SPI_TR_Byte((Addr & 0xff0000) >> 16);    //发送扇区地址bit23:16(Block编号)
    W25Qxx_SPI_TR_Byte((Addr & 0xff00) >> 8);       //发送扇区地址bit15:8(bit15:12扇区编号)
    W25Qxx_SPI_TR_Byte(Addr & 0xff);                //发送扇区地址bit7:0
    while(cnt--)
    {
        W25Qxx_SPI_TR_Byte(*buf);                   //写入数据
        buf++;                                      //数据地址指向下一个
    }    
    W25Qx_CS_1;                                     //取消片选Flash
    W25Qxx_Wait_Write_Idle();                       //等待Flash空闲
}

/**
  * @brief  写入任意长度的数据(可以跨sector写入)
  * @note   None
  * @param  Addr：起始地址
  *         *buf：待写入的数据
  *         cnt：写入数据的个数
  * @retval None
  */
void W25Qxx_Write_Data(uint32_t Addr, uint8_t *buf, uint16_t cnt)
{
    uint16_t count = 0;
    /*首地址未对齐页起始地址*/
    if(Addr & 0xff)
    {        
        while(cnt--)
        {
            count++;                                        //计数当前写入数据个数
            /*从写入地址Addr开始写满一页翻页再写入剩余数据*/
            if(count ==1 || (count & Addr) % 256 == 0)
            {
                W25Qx_CS_1;                                 //取消Flash片选
                W25Qxx_Wait_Write_Idle();                   //等待上一次数据写入完成
                W25Qxx_Write_Enable();                      //发送写使能命令
                W25Qx_CS_0;                                 //片选Flash
                W25Qxx_SPI_TR_Byte(W25Qx_PAGE_PROGRAM);     //发送页写入命令
                W25Qxx_SPI_TR_Byte((Addr & 0xff0000) >> 16);//发送扇区地址bit23:16(Block编号)
                W25Qxx_SPI_TR_Byte((Addr & 0xff00) >> 8);   //发送扇区地址bit15:8(bit15:12扇区编号)
                W25Qxx_SPI_TR_Byte(Addr & 0xff);            //发送扇区地址bit7:0
            }
            W25Qxx_SPI_TR_Byte(*buf);                       //依次发送数据至Flash
            buf++;                                          //缓存数组地址自增1
            Addr++;                                         //Flash地址加1，翻页操作使用
        }
    }
    /*首地址对齐页地址*/
    else
    {        
        while(cnt--)
        {
            count++;                                        //计数当前写入数据个数
            /*从写入地址Addr开始写满一页翻页再写入剩余数据*/
            if((count % 256) == 1)
            {
                W25Qx_CS_1;                                 //取消Flash片选
                W25Qxx_Wait_Write_Idle();                   //等待写入完成
                W25Qxx_Write_Enable();                      //写使能
                W25Qx_CS_0;                                 //片选Flash
                W25Qxx_SPI_TR_Byte(W25Qx_PAGE_PROGRAM);     //写入页写入命令
                W25Qxx_SPI_TR_Byte((Addr & 0xff0000) >> 16);//写入扇区地址bit23:16(Block编号)
                W25Qxx_SPI_TR_Byte((Addr & 0xff00) >> 8);   //发送扇区地址bit15:8(bit15:12扇区编号)
                W25Qxx_SPI_TR_Byte(Addr & 0xff);            //写入扇区地址bit7:0
            }
            W25Qxx_SPI_TR_Byte(*buf);                       //依次发送数据至Flash
            buf++;                                          //缓存数组地址自增1
            Addr++;                                         //Flash地址加1，翻页操作使用
        }
    }
    W25Qx_CS_1;                                             //取消Flash片选
    W25Qxx_Wait_Write_Idle();                               //等待写入完成
}

/**
  * @brief  读取Flash JEDEC ID
  * @note   None
  * @param  None
  * @retval Flash JEDEC ID
  */
void W25Qxx_JEDEC_ID(uint32_t *JEDEC_ID)
{
    W25Qx_CS_0;                                         //片选Flash
    W25Qxx_SPI_TR_Byte(W25Qx_JEDEC_ID);                 //发送读JEDEC ID命令
    *JEDEC_ID = W25Qxx_SPI_TR_Byte(W25Qx_Dummy_Byte);   //获取JEDEC ID:MF7-MF0
    *JEDEC_ID = *JEDEC_ID << 8;
    *JEDEC_ID |= W25Qxx_SPI_TR_Byte(W25Qx_Dummy_Byte);  //获取JEDEC ID:ID15-ID8
    *JEDEC_ID = *JEDEC_ID << 8;
    *JEDEC_ID |= W25Qxx_SPI_TR_Byte(W25Qx_Dummy_Byte);  //获取JEDEC ID:ID7-ID0
    W25Qx_CS_1;                                         //取消片选Flash
}

/**
  * @brief  使用SPI DMA获取W25Qxx DEVICE_ID
  * @note   None
  * @param  *tx_buf：读取DEVICE_ID指令(0x90)以及空指令
  *         rx_buf：接收到的DEVICE_ID
  * @retval None
  */
void W25Qxx_DMA_DEVICE_ID(uint8_t *tx_buf, uint8_t *rx_buf)
{
    uint16_t num = 60000;                       //超时计数变量
    W25Qx_SPI_DMA_TX->MADDR = (uint32_t)tx_buf; //设置SPIx_DMA_TX存储器地址(地址未更改不用重新配置)
    W25Qx_SPI_DMA_RX->MADDR = (uint32_t)rx_buf; //设置SPIx_DMA_RX存储器地址(地址未更改不用重新配置)
    W25Qx_SPI_DMA_RX->CFGR |= (uint16_t)0x0080; //使能SPIx_DMA_RX接收存储器地址递增
    W25Qx_SPI_DMA_TX->CNTR = 6;                 //设置SPIx_DMA_TX传输数据个数
    W25Qx_SPI_DMA_RX->CNTR = 6;                 //设置SPIx_DMA_RX接收数据个数
    W25Qx_CS_0;                                 //片选Flash
    W25Qx_SPI_DMA_TX->CFGR |= (uint16_t)0x0001; //使能SPIx_DMA_TX开始发送数据
    W25Qx_SPI_DMA_RX->CFGR |= (uint16_t)0x0001; //使能SPIx_DMA_RX开始接收数据
    while(!(W25Qx_SPI->STATR & SPI_I2S_FLAG_TXE) && --num); //等待SPI_SR状态寄存器TXE=1(写入SPI_DR的最后一个数据开始传输)
    num = 60000;                                //重置计数值
    while((W25Qx_SPI->STATR & SPI_I2S_FLAG_BSY) && --num);  //等待SPI_SR状态寄存器BSY=0(SPI通讯结束)
    W25Qx_CS_1;                                 //取消片选Flash
}

/**
  * @brief  使用SPI DMA获取W25Qxx UNIQUE_ID
  * @note   None
  * @param  *tx_buf：读取UNIQUE_ID指令(0x4B)以及空指令
  *         rx_buf：接收到的UNIQUE_ID
  * @retval None
  */
void W25Qxx_DMA_UNIQUE_ID(uint8_t *tx_buf, uint8_t *rx_buf)
{
    uint16_t num = 60000;                       //超时计数变量
    W25Qx_SPI_DMA_TX->MADDR = (uint32_t)tx_buf; //设置SPIx_DMA_TX存储器地址(地址未更改不用重新配置)
    W25Qx_SPI_DMA_RX->MADDR = (uint32_t)rx_buf; //设置SPIx_DMA_RX存储器地址(地址未更改不用重新配置)
    W25Qx_SPI_DMA_RX->CFGR |= (uint16_t)0x0080; //使能SPIx_DMA_RX接收存储器地址递增
    W25Qx_SPI_DMA_TX->CNTR = 13;                //设置SPIx_DMA_TX传输数据个数
    W25Qx_SPI_DMA_RX->CNTR = 13;                //设置SPIx_DMA_RX接收数据个数
    W25Qx_CS_0;                                 //片选Flash
    W25Qx_SPI_DMA_TX->CFGR |= (uint16_t)0x0001; //使能SPIx_DMA_TX开始发送数据
    W25Qx_SPI_DMA_RX->CFGR |= (uint16_t)0x0001; //使能SPIx_DMA_RX开始接收数据
    while(!(W25Qx_SPI->STATR & SPI_I2S_FLAG_TXE) && --num); //等待SPI_SR状态寄存器TXE=1(写入SPI_DR的最后一个数据开始传输)
    num = 60000;                                //重置计数值
    while((W25Qx_SPI->STATR & SPI_I2S_FLAG_BSY) && --num);  //等待SPI_SR状态寄存器BSY=0(SPI通讯结束)
    W25Qx_CS_1;                                 //取消片选Flash
}

/**
  * @brief  使用SPI DMA获取W25Qxx JEDEC_ID
  * @note   None
  * @param  *tx_buf：读取JEDEC_ID指令(0x9F)以及空指令
  *         rx_buf：接收到的JEDEC_ID
  * @retval None
  */
void W25Qxx_DMA_JEDEC_ID(uint8_t *tx_buf, uint8_t *rx_buf)
{
    uint16_t num = 60000;                       //超时计数变量
    W25Qx_SPI_DMA_TX->MADDR = (uint32_t)tx_buf; //设置SPIx_DMA_TX存储器地址(地址未更改不用重新配置)
    W25Qx_SPI_DMA_RX->MADDR = (uint32_t)rx_buf; //设置SPIx_DMA_RX存储器地址(地址未更改不用重新配置)
    W25Qx_SPI_DMA_RX->CFGR |= (uint16_t)0x0080; //使能SPIx_DMA_RX接收存储器地址递增
    W25Qx_SPI_DMA_TX->CNTR = 4;                 //设置SPIx_DMA_TX传输数据个数
    W25Qx_SPI_DMA_RX->CNTR = 4;                 //设置SPIx_DMA_RX接收数据个数
    W25Qx_CS_0;                                 //片选Flash
    W25Qx_SPI_DMA_TX->CFGR |= (uint16_t)0x0001; //使能SPIx_DMA_TX开始发送数据
    W25Qx_SPI_DMA_RX->CFGR |= (uint16_t)0x0001; //使能SPIx_DMA_RX开始接收数据
    while(!(W25Qx_SPI->STATR & SPI_I2S_FLAG_TXE) && --num); //等待SPI_SR状态寄存器TXE=1(写入SPI_DR的最后一个数据开始传输)
    num = 60000;                                //重置计数值
    while((W25Qx_SPI->STATR & SPI_I2S_FLAG_BSY) && --num);  //等待SPI_SR状态寄存器BSY=0(SPI通讯结束)
    W25Qx_CS_1;                                 //取消片选Flash
}
