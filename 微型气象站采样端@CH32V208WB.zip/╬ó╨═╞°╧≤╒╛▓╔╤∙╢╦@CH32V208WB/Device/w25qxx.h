#ifndef __W25QXX_H
#define __W25QXX_H

#include "ch32v20x.h"

/*-----W25Qxx挂载的SPI总线-----*/
#if 0
  #define W25Qx_SPI           SPI1
  #define W25Qx_SPI_DMA_TX    DMA1_Channel3
  #define W25Qx_SPI_DMA_RX    DMA1_Channel2
#else
  #define W25Qx_SPI           SPI2
  #define W25Qx_SPI_DMA_TX    DMA1_Channel5
  #define W25Qx_SPI_DMA_RX    DMA1_Channel4
#endif

/*-----W25Qxx片选引脚宏定义-----*/
#define W25Qx_CS_CLK    RCC_APB2Periph_GPIOB
#define W25Qx_CS_Port   GPIOB
#define W25Qx_CS_Pin    GPIO_Pin_12

/*-----W25Qxx片选引脚功能宏定义-----*/
#define W25Qx_CS_0      W25Qx_CS_Port->BCR = W25Qx_CS_Pin   //输出低电平(使能片选)
#define W25Qx_CS_1      W25Qx_CS_Port->BSHR = W25Qx_CS_Pin  //输出高电平(取消片选)

/*-----W25Qxx操作命令-----*/
#define W25Qx_Dummy_Byte        0xff    //发起SPI通信使用的数据(不是flash操作指令即可)
#define W25Qx_WRITE_ENABLE      0x06    //使能写入
#define W25Qx_WRITE_DISABLE     0x04    //禁止写入
#define W25Qx_READ_SR1	        0x05    //读状态寄存器1
#define W25Qx_READ_SR2 		    0x35    //读状态寄存器2
#define W25Qx_WRITE_SR1 		0x01    //写状态寄存器
#define W25Qx_READ_DATA 	    0x03 	//读数据
#define W25Qx_PAGE_PROGRAM	    0x02    //页写入(256Bytes)
#define W25Qx_BLOCK_ERASE 		0xD8    //块擦除(64KB)
#define W25Qx_HALF_BLOCK_ERASE 	0x52    //半块擦除(32KB)
#define W25Qx_SECTOR_ERASE 		0x20    //扇区擦除(4KB)
#define W25Qx_CHIP_ERASE 	    0xC7    //整片擦除
#define W25Qx_POWER_DOWN 	    0xB9    //芯片掉电
#define W25Qx_RE_POWER_DOWN	    0xAB    //芯片上电，返回器件ID
#define W25Qx_DEVICE_ID 	    0x90    //器件ID
#define W25Qx_JEDEC_ID 		    0x9F    //JEDEC ID
#define W25Qx_UNIQUE_ID         0x4B    //64位唯一序列号

void W25Qxx_CS_Init(void);
void W25Qxx_Chip_Erase(void);
void W25Qxx_Sector_Erase(uint32_t SectorAddr);
void W25Qxx_Read_Data(uint32_t Addr, uint8_t *buf, uint32_t cnt);
void W25Qxx_DMA_Read_Data(uint32_t Addr, uint8_t *buf, uint16_t cnt);
void W25Qxx_Page_Write(uint32_t Addr, uint8_t *buf, uint16_t cnt);
void W25Qxx_Write_Data(uint32_t Addr, uint8_t *buf, uint16_t cnt);
void W25Qxx_JEDEC_ID(uint32_t *JEDEC_ID);
void W25Qxx_DMA_DEVICE_ID(uint8_t *tx_buf, uint8_t *rx_buf);
void W25Qxx_DMA_UNIQUE_ID(uint8_t *tx_buf, uint8_t *rx_buf);
void W25Qxx_DMA_JEDEC_ID(uint8_t *tx_buf, uint8_t *rx_buf);

#endif  /* __W25QXX_H */
