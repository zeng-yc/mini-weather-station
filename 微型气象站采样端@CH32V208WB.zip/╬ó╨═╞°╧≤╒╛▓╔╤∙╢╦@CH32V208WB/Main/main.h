#ifndef __MAIN_H
#define __MAIN_H

#include "ch32v20x.h"
#include "systick.h"
#include "rtc.h"
#include "iwdg.h"
#include "debug.h"
#include "i2c.h"
#include "aht21b.h"
#include "bmp280.h"
#include "spi_1.h"
#include "spi_2.h"
#include "w25qxx.h"
#include "144_st7735s.h"
#include "144_lcd_app.h"
#include "144_lcd_aht21b.h"
#include "144_lcd_bmp280.h"
#include "adc.h"
#include "adc_app.h"
#include "144_lcd_adc.h"
#include "tencent.h"
#include "144_lcd_rtc.h"
#include "led.h"

/*****������״̬��ʶ������ʶλ�궨��*****/
#define MainTask_BIT0       ((uint16_t)0x0001)
#define MainTask_BIT1       ((uint16_t)0x0002)
#define MainTask_BIT2       ((uint16_t)0x0004)
#define MainTask_BIT3       ((uint16_t)0x0008)
#define MainTask_BIT4       ((uint16_t)0x0010)
#define MainTask_BIT5       ((uint16_t)0x0020)
#define MainTask_BIT6       ((uint16_t)0x0040)
#define MainTask_BIT7       ((uint16_t)0x0080)
#define MainTask_BIT8       ((uint16_t)0x0100)
#define MainTask_BIT9       ((uint16_t)0x0200)
#define MainTask_BIT10      ((uint16_t)0x0400)
#define MainTask_BIT11      ((uint16_t)0x0800)
#define MainTask_BIT12      ((uint16_t)0x1000)
#define MainTask_BIT13      ((uint16_t)0x2000)
#define MainTask_BIT14      ((uint16_t)0x4000)
#define MainTask_BIT15      ((uint16_t)0x8000)

extern __IO uint16_t MainTask;      //��������״̬��ʶ����
extern __IO uint16_t TaskCount;     //SysTick�������жϼ�������

/****************************************END OF LINE**********************************************/

#endif /* __MAIN_H */
